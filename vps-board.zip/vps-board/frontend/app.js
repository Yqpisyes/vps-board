"use strict";

const API_BASE = (
  window.VPS_BOARD_CONFIG?.API_BASE || ""
).replace(/\/$/, "");

const I18N = {
  "zh-CN": {
    total: "总数",
    online: "在线",
    settings: "设置",
    switchLanguage: "Switch to English",

    mapTitle: "服务器分布",
    mapDescription: "根据 IPinfo 返回的城市级位置显示",
    mapLoading: "正在加载地图",
    noLocation: "暂无可显示的位置",

    running: "运行中",
    offline: "离线",

    cpu: "CPU",
    memory: "内存",
    disk: "硬盘",
    download: "下行",
    upload: "上行",

    dialogTitle: "机器设置",
    dialogDescription: "选择一台机器，或添加新机器",
    adminToken: "管理员密钥",
    adminHelp: "密钥只保存在当前浏览器标签页。",
    selectMachine: "选择机器",
    addMachine: "＋ 添加新机器",
    machineName: "机器名称",
    provider: "机器提供商（可选）",
    ispHelp: "ISP、位置和风险由后端自动识别。",

    delete: "删除机器",
    rotate: "重置 Token",
    refresh: "刷新网络信息",
    save: "保存",
    copy: "复制 Token",
    tokenTitle: "Agent Token 只显示一次，请立即保存",

    emptyTitle: "没有 VPS，请添加",
    emptyDescription: "添加机器后，再安装监控 Agent。",
    addVPS: "添加 VPS",

    saved: "设置已保存",
    created: "机器已添加，请立即复制 Agent Token",
    deleted: "机器已删除",
    rotated: "Token 已重置，请立即保存",
    copied: "Token 已复制",
    refreshed: "网络缓存已清除",

    unauthorized: "管理员密钥不正确",
    requestFailed: "请求后端失败",
    invalidResponse: "后端返回了无效响应",
    confirmDelete: "确定删除这台机器吗？",
    confirmRotate: "重置后旧 Token 会失效，继续吗？"
  },

  en: {
    total: "Total",
    online: "Online",
    settings: "Settings",
    switchLanguage: "切换到中文",

    mapTitle: "Server Distribution",
    mapDescription: "City-level locations provided by IPinfo",
    mapLoading: "Loading map",
    noLocation: "No location data available",

    running: "Online",
    offline: "Offline",

    cpu: "CPU",
    memory: "Memory",
    disk: "Disk",
    download: "Down",
    upload: "Up",

    dialogTitle: "Machine Settings",
    dialogDescription: "Select a machine or add a new one",
    adminToken: "Admin token",
    adminHelp: "Stored only in the current browser tab.",
    selectMachine: "Select machine",
    addMachine: "＋ Add new machine",
    machineName: "Machine name",
    provider: "Machine provider (optional)",
    ispHelp: "ISP, location and risk are detected automatically.",

    delete: "Delete",
    rotate: "Reset Token",
    refresh: "Refresh Network",
    save: "Save",
    copy: "Copy Token",
    tokenTitle: "The Agent Token is shown once. Save it now.",

    emptyTitle: "No VPS. Please add one.",
    emptyDescription: "Add a machine, then install the agent.",
    addVPS: "Add VPS",

    saved: "Settings saved",
    created: "Machine created. Copy the Agent Token now.",
    deleted: "Machine deleted",
    rotated: "Token reset. Save it now.",
    copied: "Token copied",
    refreshed: "Network cache cleared",

    unauthorized: "Invalid administrator token",
    requestFailed: "Backend request failed",
    invalidResponse: "The backend returned an invalid response",
    confirmDelete: "Delete this machine?",
    confirmRotate: "The old Token will stop working. Continue?"
  }
};

const machineGrid =
  document.getElementById("machineGrid");

const vpsCount =
  document.getElementById("vpsCount");

const onlineCount =
  document.getElementById("onlineCount");

const languageButton =
  document.getElementById("languageButton");

const settingsModal =
  document.getElementById("settingsModal");

const adminTokenInput =
  document.getElementById("adminTokenInput");

const machineSelect =
  document.getElementById("machineSelect");

const machineNameInput =
  document.getElementById("machineNameInput");

const providerInput =
  document.getElementById("providerInput");

const agentTokenBox =
  document.getElementById("agentTokenBox");

const agentTokenValue =
  document.getElementById("agentTokenValue");

const deleteButton =
  document.getElementById("deleteButton");

const rotateTokenButton =
  document.getElementById("rotateTokenButton");

const refreshNetworkButton =
  document.getElementById("refreshNetworkButton");

const toast =
  document.getElementById("toast");

let language =
  localStorage.getItem("vps-language") === "en"
    ? "en"
    : "zh-CN";

let machines = [];
let eventSource = null;
let worldMap = null;
let markerLayer = null;
let mapHasFitted = false;
let toastTimer = null;

function t(key) {
  return I18N[language][key] || key;
}

function escapeHtml(value) {
  return String(value ?? "").replace(
    /[&<>"']/g,
    character => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#039;"
    })[character]
  );
}

function showToast(message) {
  clearTimeout(toastTimer);

  toast.textContent = message;
  toast.classList.add("show");

  toastTimer = setTimeout(() => {
    toast.classList.remove("show");
  }, 2200);
}

function formatRate(bytes) {
  const value = Math.max(
    0,
    Number(bytes || 0)
  );

  if (value < 1024) {
    return `${Math.round(value)} B/s`;
  }

  const units = [
    "KiB/s",
    "MiB/s",
    "GiB/s",
    "TiB/s"
  ];

  const index = Math.min(
    Math.max(
      0,
      Math.floor(
        Math.log(value) /
        Math.log(1024)
      ) - 1
    ),
    units.length - 1
  );

  const converted =
    value / Math.pow(1024, index + 1);

  return `${
    converted.toFixed(
      converted >= 100
        ? 0
        : converted >= 10
          ? 1
          : 2
    )
  } ${units[index]}`;
}

function isOnline(machine) {
  const value =
    machine.metrics?.lastSeenAt;

  if (!value) {
    return false;
  }

  return (
    Date.now() -
    new Date(value).getTime()
  ) <= 25000;
}

function flagURL(machine) {
  const code = String(
    machine.network?.countryCode || ""
  ).toLowerCase();

  return /^[a-z]{2}$/.test(code)
    ? `https://flagcdn.com/${code}.svg`
    : "";
}

function locationText(machine) {
  return (
    machine.network?.city ||
    machine.network?.region ||
    machine.network?.countryCode ||
    ""
  );
}

function renderCard(machine) {
  const online = isOnline(machine);
  const flag = flagURL(machine);

  const cpu = Number(
    machine.metrics?.cpuUsage || 0
  );

  const memory = Number(
    machine.metrics?.memoryUsage || 0
  );

  const disk = Number(
    machine.metrics?.diskUsage || 0
  );

  return `
    <a
      class="compact-machine-card"
      href="/detail.html?id=${encodeURIComponent(machine.id)}"
    >
      <header class="compact-card-header">
        <div class="compact-title">
          <h2>${escapeHtml(machine.name)}</h2>

          ${
            flag
              ? `
                <img
                  class="country-flag"
                  src="${escapeHtml(flag)}"
                  alt="${escapeHtml(
                    machine.network?.countryCode || ""
                  )}"
                >
              `
              : ""
          }

          <span class="compact-location">
            ${escapeHtml(locationText(machine))}
          </span>
        </div>

        <span class="compact-status ${online ? "online" : ""}">
          <i></i>
          ${escapeHtml(
            online
              ? t("running")
              : t("offline")
          )}
        </span>
      </header>

      <div class="compact-metrics">
        ${metricBox(t("cpu"), cpu)}
        ${metricBox(t("memory"), memory)}
        ${metricBox(t("disk"), disk)}
      </div>

      <div class="compact-network">
        <span class="download">
          ↓ ${escapeHtml(t("download"))}
          <strong>
            ${escapeHtml(
              formatRate(
                machine.metrics?.networkDownloadBps
              )
            )}
          </strong>
        </span>

        <span class="upload">
          ↑ ${escapeHtml(t("upload"))}
          <strong>
            ${escapeHtml(
              formatRate(
                machine.metrics?.networkUploadBps
              )
            )}
          </strong>
        </span>
      </div>
    </a>
  `;
}

function metricBox(label, value) {
  const safe = Math.min(
    100,
    Math.max(0, Number(value || 0))
  );

  return `
    <div class="compact-metric">
      <div>
        <span>${escapeHtml(label)}</span>
        <strong>${safe.toFixed(1)}%</strong>
      </div>

      <div class="progress">
        <i style="width:${safe}%"></i>
      </div>
    </div>
  `;
}

function renderDashboard() {
  const online =
    machines.filter(isOnline).length;

  vpsCount.textContent =
    String(machines.length);

  onlineCount.textContent =
    String(online);

  if (machines.length === 0) {
    machineGrid.innerHTML = `
      <div class="empty-state">
        <div>
          <div class="empty-icon">☁</div>
          <h2>${escapeHtml(t("emptyTitle"))}</h2>
          <p>${escapeHtml(t("emptyDescription"))}</p>

          <button
            class="normal-button primary"
            id="emptyAddButton"
            type="button"
          >
            ${escapeHtml(t("addVPS"))}
          </button>
        </div>
      </div>
    `;

    document
      .getElementById("emptyAddButton")
      .addEventListener(
        "click",
        () => openSettings(true)
      );
  } else {
    machineGrid.innerHTML =
      machines.map(renderCard).join("");
  }

  renderMap();
}

function initializeMap() {
  if (
    worldMap ||
    typeof window.L === "undefined"
  ) {
    return;
  }

  worldMap = L.map(
    "worldMap",
    {
      worldCopyJump: true,
      minZoom: 1,
      maxZoom: 8
    }
  ).setView([20, 0], 2);

  L.tileLayer(
    "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",
    {
      attribution:
        "&copy; OpenStreetMap &copy; CARTO",
      subdomains: "abcd",
      maxZoom: 20
    }
  ).addTo(worldMap);

  markerLayer =
    L.layerGroup().addTo(worldMap);

  document
    .getElementById("mapLoading")
    ?.remove();
}

function renderMap() {
  initializeMap();

  if (!worldMap || !markerLayer) {
    return;
  }

  markerLayer.clearLayers();

  const located = machines.filter(
    machine =>
      Number.isFinite(
        Number(machine.network?.latitude)
      ) &&
      Number.isFinite(
        Number(machine.network?.longitude)
      )
  );

  if (located.length === 0) {
    return;
  }

  const bounds = [];

  for (const machine of located) {
    const latitude =
      Number(machine.network.latitude);

    const longitude =
      Number(machine.network.longitude);

    const online = isOnline(machine);

    const marker = L.circleMarker(
      [latitude, longitude],
      {
        radius: 8,
        color: online
          ? "#15856b"
          : "#77716d",
        fillColor: online
          ? "#20c99a"
          : "#aaa39e",
        fillOpacity: 0.85,
        weight: 2
      }
    );

    marker.bindPopup(`
      <div class="map-popup">
        <strong>${escapeHtml(machine.name)}</strong>
        <span>${escapeHtml(locationText(machine))}</span>
        <a href="/detail.html?id=${encodeURIComponent(machine.id)}">
          ${escapeHtml(
            language === "en"
              ? "View details"
              : "查看详情"
          )}
        </a>
      </div>
    `);

    marker.addTo(markerLayer);
    bounds.push([latitude, longitude]);
  }

  if (!mapHasFitted) {
    worldMap.fitBounds(
      bounds,
      {
        padding: [30, 30],
        maxZoom: 4
      }
    );

    mapHasFitted = true;
  }
}

async function apiRequest(
  path,
  options = {},
  admin = false
) {
  const headers = {
    Accept: "application/json",
    ...(options.headers || {})
  };

  if (options.body) {
    headers["Content-Type"] =
      "application/json";
  }

  if (admin) {
    const token =
      adminTokenInput.value.trim();

    headers.Authorization =
      `Bearer ${token}`;

    sessionStorage.setItem(
      "vps-admin-token",
      token
    );
  }

  const response = await fetch(
    API_BASE + path,
    {
      ...options,
      headers
    }
  );

  if (response.status === 204) {
    return null;
  }

  const text = await response.text();
  let data = null;

  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    throw new Error(t("invalidResponse"));
  }

  if (response.status === 401) {
    throw new Error(t("unauthorized"));
  }

  if (!response.ok) {
    throw new Error(
      data?.detail || t("requestFailed")
    );
  }

  return data;
}

async function loadMachines() {
  try {
    const data = await apiRequest(
      "/api/v1/public/machines"
    );

    machines = data?.machines || [];

    updateMachineOptions(
      machineSelect.value,
      false
    );

    renderDashboard();
  } catch (error) {
    showToast(error.message);
  }
}

function upsertMachine(machine) {
  const index = machines.findIndex(
    item => item.id === machine.id
  );

  if (index === -1) {
    machines.push(machine);
  } else {
    machines[index] = machine;
  }

  updateMachineOptions(
    machineSelect.value,
    false
  );

  renderDashboard();
}

function connectEvents() {
  eventSource?.close();

  eventSource = new EventSource(
    API_BASE +
    "/api/v1/public/events"
  );

  eventSource.addEventListener(
    "snapshot",
    event => {
      const data = JSON.parse(event.data);
      machines = data.machines || [];

      updateMachineOptions(
        machineSelect.value,
        false
      );

      renderDashboard();
    }
  );

  eventSource.addEventListener(
    "machine",
    event => {
      upsertMachine(
        JSON.parse(event.data)
      );
    }
  );

  eventSource.addEventListener(
    "deleted",
    event => {
      const data = JSON.parse(event.data);

      machines = machines.filter(
        machine => machine.id !== data.id
      );

      updateMachineOptions(
        "__new__",
        true
      );

      renderDashboard();
    }
  );
}

function updateMachineOptions(
  selectedValue,
  fillForm
) {
  const current =
    selectedValue ||
    machineSelect.value ||
    machines[0]?.id ||
    "__new__";

  machineSelect.innerHTML = `
    <option value="__new__">
      ${escapeHtml(t("addMachine"))}
    </option>

    ${machines.map(machine => `
      <option value="${escapeHtml(machine.id)}">
        ${escapeHtml(machine.name)}
      </option>
    `).join("")}
  `;

  machineSelect.value =
    current === "__new__" ||
    machines.some(
      machine => machine.id === current
    )
      ? current
      : "__new__";

  if (fillForm) {
    fillMachineForm();
  }
}

function fillMachineForm() {
  agentTokenBox.hidden = true;

  if (machineSelect.value === "__new__") {
    machineNameInput.value = "";
    providerInput.value = "";

    deleteButton.hidden = true;
    rotateTokenButton.hidden = true;
    refreshNetworkButton.hidden = true;

    return;
  }

  const machine = machines.find(
    item => item.id === machineSelect.value
  );

  if (!machine) {
    return;
  }

  machineNameInput.value = machine.name || "";
  providerInput.value = machine.provider || "";

  deleteButton.hidden = false;
  rotateTokenButton.hidden = false;
  refreshNetworkButton.hidden = false;
}

function openSettings(createNew = false) {
  adminTokenInput.value =
    sessionStorage.getItem(
      "vps-admin-token"
    ) || "";

  updateMachineOptions(
    createNew
      ? "__new__"
      : machineSelect.value,
    true
  );

  settingsModal.classList.add("open");
  settingsModal.setAttribute(
    "aria-hidden",
    "false"
  );

  document.body.classList.add(
    "modal-open"
  );
}

function closeSettings() {
  settingsModal.classList.remove("open");
  settingsModal.setAttribute(
    "aria-hidden",
    "true"
  );

  document.body.classList.remove(
    "modal-open"
  );
}

function showAgentToken(token) {
  agentTokenValue.textContent = token;
  agentTokenBox.hidden = false;
}

function applyLanguage() {
  document.documentElement.lang =
    language;

  document.getElementById(
    "totalLabel"
  ).textContent = t("total");

  document.getElementById(
    "onlineLabel"
  ).textContent = t("online");

  document.getElementById(
    "settingsText"
  ).textContent = t("settings");

  document.getElementById(
    "mapTitle"
  ).textContent = t("mapTitle");

  document.getElementById(
    "mapDescription"
  ).textContent = t("mapDescription");

  languageButton.title =
    t("switchLanguage");

  document.getElementById(
    "dialogTitle"
  ).textContent = t("dialogTitle");

  document.getElementById(
    "dialogDescription"
  ).textContent = t("dialogDescription");

  document.getElementById(
    "adminTokenLabel"
  ).textContent = t("adminToken");

  document.getElementById(
    "adminTokenHelp"
  ).textContent = t("adminHelp");

  document.getElementById(
    "machineSelectLabel"
  ).textContent = t("selectMachine");

  document.getElementById(
    "machineNameLabel"
  ).textContent = t("machineName");

  document.getElementById(
    "providerLabel"
  ).textContent = t("provider");

  document.getElementById(
    "ispHelp"
  ).textContent = t("ispHelp");

  document.getElementById(
    "agentTokenTitle"
  ).textContent = t("tokenTitle");

  document.getElementById(
    "copyTokenButton"
  ).textContent = t("copy");

  deleteButton.textContent = t("delete");
  rotateTokenButton.textContent = t("rotate");
  refreshNetworkButton.textContent = t("refresh");

  document.getElementById(
    "saveButton"
  ).textContent = t("save");

  updateMachineOptions(
    machineSelect.value,
    false
  );

  renderDashboard();
}

document
  .getElementById("settingsForm")
  .addEventListener(
    "submit",
    async event => {
      event.preventDefault();

      const machineID =
        machineSelect.value;

      const payload = {
        name:
          machineNameInput.value.trim(),

        provider:
          providerInput.value.trim()
      };

      try {
        if (machineID === "__new__") {
          const data = await apiRequest(
            "/api/v1/admin/machines",
            {
              method: "POST",
              body: JSON.stringify(payload)
            },
            true
          );

          upsertMachine(data.machine);

          updateMachineOptions(
            data.machine.id,
            true
          );

          showAgentToken(
            data.agentToken
          );

          showToast(t("created"));
        } else {
          const data = await apiRequest(
            "/api/v1/admin/machines/" +
            encodeURIComponent(machineID),
            {
              method: "PUT",
              body: JSON.stringify(payload)
            },
            true
          );

          upsertMachine(data.machine);
          showToast(t("saved"));
        }
      } catch (error) {
        showToast(error.message);
      }
    }
  );

deleteButton.addEventListener(
  "click",
  async () => {
    const machineID =
      machineSelect.value;

    if (
      machineID === "__new__" ||
      !confirm(t("confirmDelete"))
    ) {
      return;
    }

    try {
      await apiRequest(
        "/api/v1/admin/machines/" +
        encodeURIComponent(machineID),
        {
          method: "DELETE"
        },
        true
      );

      machines = machines.filter(
        machine => machine.id !== machineID
      );

      updateMachineOptions(
        "__new__",
        true
      );

      renderDashboard();
      showToast(t("deleted"));
    } catch (error) {
      showToast(error.message);
    }
  }
);

rotateTokenButton.addEventListener(
  "click",
  async () => {
    const machineID =
      machineSelect.value;

    if (
      machineID === "__new__" ||
      !confirm(t("confirmRotate"))
    ) {
      return;
    }

    try {
      const data = await apiRequest(
        "/api/v1/admin/machines/" +
        encodeURIComponent(machineID) +
        "/rotate-token",
        {
          method: "POST"
        },
        true
      );

      showAgentToken(
        data.agentToken
      );

      showToast(t("rotated"));
    } catch (error) {
      showToast(error.message);
    }
  }
);

refreshNetworkButton.addEventListener(
  "click",
  async () => {
    const machineID =
      machineSelect.value;

    if (machineID === "__new__") {
      return;
    }

    try {
      await apiRequest(
        "/api/v1/admin/machines/" +
        encodeURIComponent(machineID) +
        "/network/refresh",
        {
          method: "POST"
        },
        true
      );

      showToast(t("refreshed"));
    } catch (error) {
      showToast(error.message);
    }
  }
);

document
  .getElementById("copyTokenButton")
  .addEventListener(
    "click",
    async () => {
      try {
        await navigator.clipboard.writeText(
          agentTokenValue.textContent
        );

        showToast(t("copied"));
      } catch {
        showToast(t("requestFailed"));
      }
    }
  );

machineSelect.addEventListener(
  "change",
  fillMachineForm
);

languageButton.addEventListener(
  "click",
  () => {
    language =
      language === "en"
        ? "zh-CN"
        : "en";

    localStorage.setItem(
      "vps-language",
      language
    );

    applyLanguage();
  }
);

document
  .getElementById("openSettingsButton")
  .addEventListener(
    "click",
    () => openSettings(false)
  );

document
  .getElementById("closeModalButton")
  .addEventListener(
    "click",
    closeSettings
  );

document
  .getElementById("modalBackdrop")
  .addEventListener(
    "click",
    closeSettings
  );

document.addEventListener(
  "keydown",
  event => {
    if (event.key === "Escape") {
      closeSettings();
    }
  }
);

setInterval(
  renderDashboard,
  5000
);

applyLanguage();
loadMachines();
connectEvents();