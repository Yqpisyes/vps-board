window.VPS_BOARD_CONFIG = {
  API_BASE: "https://server.rdd.moe"
};