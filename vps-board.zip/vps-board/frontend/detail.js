"use strict";

const API_BASE = (
  window.VPS_BOARD_CONFIG?.API_BASE || ""
).replace(/\/$/, "");

const machineID =
  new URLSearchParams(
    window.location.search
  ).get("id") || "";

const I18N = {
  "zh-CN": {
    back: "← 返回",
    switchLanguage: "Switch to English",

    running: "运行中",
    offline: "离线",

    provider: "提供商",
    isp: "网络运营商",
    asn: "ASN",
    networkType: "网络类型",
    risk: "IP 风险",
    system: "系统",
    architecture: "架构",
    cores: "CPU 核心",
    memory: "总内存",
    disk: "总硬盘",
    uptime: "本次运行",
    totalOnline: "累计在线",
    sla: "30 天 SLA",
    location: "位置",
    lastReport: "最后上报",

    cpuChart: "CPU 趋势 · 24 小时",
    resourceChart: "内存与硬盘趋势 · 24 小时",
    networkChart: "网络趋势 · 24 小时",

    cpu: "CPU",
    memoryUsage: "内存",
    diskUsage: "硬盘",
    download: "下行",
    upload: "上行",

    noData: "历史数据正在积累",
    loadFailed: "加载机器详情失败"
  },

  en: {
    back: "← Back",
    switchLanguage: "切换到中文",

    running: "Online",
    offline: "Offline",

    provider: "Provider",
    isp: "Network ISP",
    asn: "ASN",
    networkType: "Network Type",
    risk: "IP Risk",
    system: "System",
    architecture: "Architecture",
    cores: "CPU Cores",
    memory: "Total Memory",
    disk: "Total Disk",
    uptime: "System Uptime",
    totalOnline: "Observed Online",
    sla: "30-day SLA",
    location: "Location",
    lastReport: "Last Report",

    cpuChart: "CPU Trend · 24 Hours",
    resourceChart: "Memory & Disk · 24 Hours",
    networkChart: "Network Trend · 24 Hours",

    cpu: "CPU",
    memoryUsage: "Memory",
    diskUsage: "Disk",
    download: "Download",
    upload: "Upload",

    noData: "Historical data is being collected",
    loadFailed: "Failed to load machine details"
  }
};

let language =
  localStorage.getItem("vps-language") === "en"
    ? "en"
    : "zh-CN";

let machine = null;
let history = [];
let sla = null;
let eventSource = null;

const content =
  document.getElementById("detailContent");

const languageButton =
  document.getElementById("languageButton");

function t(key) {
  return I18N[language][key] || key;
}

function escapeHtml(value) {
  return String(value ?? "").replace(
    /[&<>"']/g,
    character => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#039;"
    })[character]
  );
}

function formatBytes(bytes) {
  const value = Number(bytes || 0);

  if (value <= 0) {
    return "-";
  }

  const units = [
    "B",
    "KiB",
    "MiB",
    "GiB",
    "TiB"
  ];

  const index = Math.min(
    Math.floor(
      Math.log(value) / Math.log(1024)
    ),
    units.length - 1
  );

  return `${
    (
      value /
      Math.pow(1024, index)
    ).toFixed(index === 0 ? 0 : 1)
  } ${units[index]}`;
}

function formatRate(bytes) {
  const value = Number(bytes || 0);

  if (value < 1024) {
    return `${Math.round(value)} B/s`;
  }

  const units = [
    "KiB/s",
    "MiB/s",
    "GiB/s"
  ];

  const index = Math.min(
    Math.floor(
      Math.log(value) / Math.log(1024)
    ) - 1,
    units.length - 1
  );

  return `${
    (
      value /
      Math.pow(1024, index + 1)
    ).toFixed(2)
  } ${units[index]}`;
}

function formatDuration(seconds) {
  let value = Math.max(
    0,
    Math.floor(Number(seconds || 0))
  );

  const days =
    Math.floor(value / 86400);

  value %= 86400;

  const hours =
    Math.floor(value / 3600);

  value %= 3600;

  const minutes =
    Math.floor(value / 60);

  if (language === "en") {
    return `${days}d ${hours}h ${minutes}m`;
  }

  return `${days}天 ${hours}小时 ${minutes}分`;
}

function isOnline(value) {
  const lastSeen =
    value.metrics?.lastSeenAt;

  return (
    lastSeen &&
    Date.now() -
      new Date(lastSeen).getTime()
    <= 25000
  );
}

function flagURL() {
  const code = String(
    machine?.network?.countryCode || ""
  ).toLowerCase();

  return /^[a-z]{2}$/.test(code)
    ? `https://flagcdn.com/${code}.svg`
    : "";
}

function detailItem(label, value) {
  return `
    <div class="detail-item">
      <span>${escapeHtml(label)}</span>
      <strong>${escapeHtml(value || "-")}</strong>
    </div>
  `;
}

function renderDetails() {
  if (!machine) {
    return;
  }

  const online = isOnline(machine);
  const flag = flagURL();

  const location = [
    machine.network?.city,
    machine.network?.region,
    machine.network?.countryCode
  ]
    .filter(Boolean)
    .join(", ");

  content.innerHTML = `
    <article class="detail-overview">
      <header class="detail-title-row">
        <div>
          <div class="detail-name-line">
            <h1>${escapeHtml(machine.name)}</h1>

            ${
              flag
                ? `
                  <img
                    class="country-flag detail-flag"
                    src="${escapeHtml(flag)}"
                    alt="${escapeHtml(
                      machine.network?.countryCode || ""
                    )}"
                  >
                `
                : ""
            }
          </div>

          <p>${escapeHtml(location)}</p>
        </div>

        <span class="compact-status ${online ? "online" : ""}">
          <i></i>
          ${escapeHtml(
            online
              ? t("running")
              : t("offline")
          )}
        </span>
      </header>

      <div class="detail-grid">
        ${detailItem(
          t("provider"),
          machine.provider
        )}

        ${detailItem(
          t("isp"),
          machine.network?.isp
        )}

        ${detailItem(
          t("asn"),
          machine.network?.asn
        )}

        ${detailItem(
          t("networkType"),
          machine.network?.type
        )}

        ${detailItem(
          t("risk"),
          machine.network
            ? `${machine.network.riskScore}/100`
            : "-"
        )}

        ${detailItem(
          t("location"),
          location
        )}

        ${detailItem(
          t("system"),
          [
            machine.system?.osName,
            machine.system?.osVersion
          ].filter(Boolean).join(" ")
        )}

        ${detailItem(
          t("architecture"),
          machine.system?.architecture
        )}

        ${detailItem(
          t("cores"),
          String(
            machine.metrics?.cpuCores || "-"
          )
        )}

        ${detailItem(
          t("memory"),
          formatBytes(
            machine.metrics?.memoryTotalBytes
          )
        )}

        ${detailItem(
          t("disk"),
          formatBytes(
            machine.metrics?.diskTotalBytes
          )
        )}

        ${detailItem(
          t("uptime"),
          formatDuration(
            machine.system?.uptimeSeconds
          )
        )}

        ${detailItem(
          t("totalOnline"),
          formatDuration(
            machine.metrics?.totalOnlineSeconds
          )
        )}

        ${detailItem(
          t("sla"),
          sla
            ? `${sla.sla.toFixed(4)}%`
            : "-"
        )}

        ${detailItem(
          t("lastReport"),
          machine.metrics?.lastSeenAt
            ? new Date(
                machine.metrics.lastSeenAt
              ).toLocaleString(language)
            : "-"
        )}
      </div>
    </article>
  `;
}

function createPath(
  points,
  key,
  maximum,
  width,
  height
) {
  if (points.length === 0) {
    return "";
  }

  let path = "";

  points.forEach((point, index) => {
    const x =
      points.length === 1
        ? 0
        : (
            index /
            (points.length - 1)
          ) * width;

    const value =
      Math.max(
        0,
        Number(point[key] || 0)
      );

    const y =
      height -
      (
        value /
        Math.max(1, maximum)
      ) * height;

    path += `${
      index === 0
        ? "M"
        : "L"
    }${x.toFixed(2)},${y.toFixed(2)} `;
  });

  return path;
}

function renderChart(
  elementID,
  series,
  maximum,
  formatter
) {
  const element =
    document.getElementById(elementID);

  if (history.length < 2) {
    element.innerHTML = `
      <div class="chart-empty">
        ${escapeHtml(t("noData"))}
      </div>
    `;
    return;
  }

  const width = 760;
  const height = 220;

  const paths = series.map(item => `
    <path
      class="history-line"
      d="${createPath(
        history,
        item.key,
        maximum,
        width,
        height
      )}"
      stroke="${item.color}"
    ></path>
  `).join("");

  element.innerHTML = `
    <div class="chart-legend">
      ${series.map(item => `
        <span>
          <i style="background:${item.color}"></i>
          ${escapeHtml(item.label)}
        </span>
      `).join("")}
    </div>

    <div class="chart-canvas">
      <svg
        viewBox="0 0 ${width} ${height}"
        preserveAspectRatio="none"
      >
        <line
          class="chart-grid-line"
          x1="0"
          y1="${height / 2}"
          x2="${width}"
          y2="${height / 2}"
        ></line>

        <line
          class="chart-grid-line"
          x1="0"
          y1="${height - 1}"
          x2="${width}"
          y2="${height - 1}"
        ></line>

        ${paths}
      </svg>

      <div class="chart-tooltip" hidden></div>
    </div>
  `;

  const canvas =
    element.querySelector(".chart-canvas");

  const tooltip =
    element.querySelector(".chart-tooltip");

  canvas.addEventListener(
    "pointermove",
    event => {
      const rectangle =
        canvas.getBoundingClientRect();

      const ratio = Math.min(
        1,
        Math.max(
          0,
          (
            event.clientX -
            rectangle.left
          ) / rectangle.width
        )
      );

      const index = Math.min(
        history.length - 1,
        Math.round(
          ratio *
          (history.length - 1)
        )
      );

      const point = history[index];

      tooltip.innerHTML = `
        <strong>
          ${escapeHtml(
            new Date(
              point.time * 1000
            ).toLocaleString(language)
          )}
        </strong>

        ${series.map(item => `
          <span style="color:${item.color}">
            ${escapeHtml(item.label)}:
            ${escapeHtml(
              formatter(point[item.key])
            )}
          </span>
        `).join("")}
      `;

      tooltip.hidden = false;

      tooltip.style.left =
        `${Math.min(
          rectangle.width - 170,
          Math.max(
            0,
            event.clientX -
            rectangle.left +
            10
          )
        )}px`;
    }
  );

  canvas.addEventListener(
    "pointerleave",
    () => {
      tooltip.hidden = true;
    }
  );
}

function renderCharts() {
  renderChart(
    "cpuChart",
    [
      {
        key: "cpuUsage",
        label: t("cpu"),
        color: "#20a987"
      }
    ],
    100,
    value => `${Number(value).toFixed(1)}%`
  );

  renderChart(
    "resourceChart",
    [
      {
        key: "memoryUsage",
        label: t("memoryUsage"),
        color: "#36a875"
      },
      {
        key: "diskUsage",
        label: t("diskUsage"),
        color: "#815ac0"
      }
    ],
    100,
    value => `${Number(value).toFixed(1)}%`
  );

  const networkMaximum = Math.max(
    1,
    ...history.map(
      point => Math.max(
        point.networkDownloadBps || 0,
        point.networkUploadBps || 0
      )
    )
  );

  renderChart(
    "networkChart",
    [
      {
        key: "networkDownloadBps",
        label: t("download"),
        color: "#329bd2"
      },
      {
        key: "networkUploadBps",
        label: t("upload"),
        color: "#ed7a2b"
      }
    ],
    networkMaximum,
    formatRate
  );
}

async function fetchJSON(path) {
  const response = await fetch(
    API_BASE + path,
    {
      headers: {
        Accept: "application/json"
      }
    }
  );

  if (!response.ok) {
    throw new Error(t("loadFailed"));
  }

  return response.json();
}

async function loadAll() {
  if (!/^[a-f0-9]{24}$/i.test(machineID)) {
    content.innerHTML = `
      <div class="detail-loading">
        ${escapeHtml(t("loadFailed"))}
      </div>
    `;
    return;
  }

  try {
    const [
      machineResponse,
      historyResponse,
      slaResponse
    ] = await Promise.all([
      fetchJSON(
        `/api/v1/public/machines/${encodeURIComponent(machineID)}`
      ),

      fetchJSON(
        `/api/v1/public/machines/${encodeURIComponent(machineID)}/history`
      ),

      fetchJSON(
        `/api/v1/public/machines/${encodeURIComponent(machineID)}/sla`
      )
    ]);

    machine =
      machineResponse.machine;

    history =
      historyResponse.points || [];

    sla = slaResponse;

    renderDetails();
    renderCharts();
  } catch {
    content.innerHTML = `
      <div class="detail-loading">
        ${escapeHtml(t("loadFailed"))}
      </div>
    `;
  }
}

function connectEvents() {
  eventSource = new EventSource(
    API_BASE +
    "/api/v1/public/events"
  );

  eventSource.addEventListener(
    "machine",
    event => {
      const updated =
        JSON.parse(event.data);

      if (updated.id === machineID) {
        machine = updated;
        renderDetails();
      }
    }
  );
}

function applyLanguage() {
  document.documentElement.lang =
    language;

  document.getElementById(
    "backButton"
  ).textContent = t("back");

  languageButton.title =
    t("switchLanguage");

  document.getElementById(
    "cpuChartTitle"
  ).textContent = t("cpuChart");

  document.getElementById(
    "resourceChartTitle"
  ).textContent = t("resourceChart");

  document.getElementById(
    "networkChartTitle"
  ).textContent = t("networkChart");

  renderDetails();
  renderCharts();
}

languageButton.addEventListener(
  "click",
  () => {
    language =
      language === "en"
        ? "zh-CN"
        : "en";

    localStorage.setItem(
      "vps-language",
      language
    );

    applyLanguage();
  }
);

setInterval(
  loadAll,
  60000
);

applyLanguage();
loadAll();
connectEvents();