package main

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/signal"
	"runtime"
	"strconv"
	"strings"
	"syscall"
	"time"
)

type configuration struct {
	APIURL          string
	AgentToken      string
	Interval        time.Duration
	RequestTimeout  time.Duration
	RootFilesystem  string
	NetworkInterface string
}

type report struct {
	OSID         string `json:"osId"`
	OSName       string `json:"osName"`
	OSVersion    string `json:"osVersion"`
	Architecture string `json:"architecture"`

	CPUCores int     `json:"cpuCores"`
	CPUUsage float64 `json:"cpuUsage"`

	MemoryTotalBytes int64 `json:"memoryTotalBytes"`
	MemoryUsedBytes  int64 `json:"memoryUsedBytes"`

	DiskTotalBytes int64 `json:"diskTotalBytes"`
	DiskUsedBytes  int64 `json:"diskUsedBytes"`

	NetworkDownloadBps float64 `json:"networkDownloadBps"`
	NetworkUploadBps   float64 `json:"networkUploadBps"`

	UptimeSeconds int64 `json:"uptimeSeconds"`
}

type cpuSample struct {
	Idle  uint64
	Total uint64
}

type networkSample struct {
	Received    uint64
	Transmitted uint64
}

func env(name, fallback string) string {
	value := strings.TrimSpace(os.Getenv(name))

	if value == "" {
		return fallback
	}

	return value
}

func envInt(name string, fallback int) int {
	value, err := strconv.Atoi(env(name, ""))

	if err != nil {
		return fallback
	}

	return value
}

func loadConfig() (configuration, error) {
	apiURL := strings.TrimRight(
		env("API_URL", ""),
		"/",
	)

	token := env("AGENT_TOKEN", "")

	if apiURL == "" || token == "" {
		return configuration{},
			errors.New(
				"缺少 API_URL 或 AGENT_TOKEN",
			)
	}

	interval := envInt("REPORT_INTERVAL", 5)

	if interval < 3 {
		interval = 3
	}

	return configuration{
		APIURL:     apiURL,
		AgentToken: token,

		Interval: time.Duration(
			interval,
		) * time.Second,

		RequestTimeout: time.Duration(
			envInt("REQUEST_TIMEOUT", 10),
		) * time.Second,

		RootFilesystem: env(
			"ROOT_FILESYSTEM",
			"/",
		),

		NetworkInterface: env(
			"NETWORK_INTERFACE",
			"",
		),
	}, nil
}

func readOSRelease() map[string]string {
	result := map[string]string{
		"ID":         "linux",
		"NAME":       "Linux",
		"VERSION_ID": "",
	}

	file, err := os.Open("/etc/os-release")

	if err != nil {
		return result
	}

	defer file.Close()

	scanner := bufio.NewScanner(file)

	for scanner.Scan() {
		line := strings.TrimSpace(
			scanner.Text(),
		)

		if line == "" ||
			strings.HasPrefix(line, "#") ||
			!strings.Contains(line, "=") {
			continue
		}

		parts := strings.SplitN(line, "=", 2)

		result[parts[0]] = strings.Trim(
			strings.TrimSpace(parts[1]),
			`"'`,
		)
	}

	return result
}

func readCPU() (cpuSample, error) {
	file, err := os.Open("/proc/stat")

	if err != nil {
		return cpuSample{}, err
	}

	defer file.Close()

	scanner := bufio.NewScanner(file)

	if !scanner.Scan() {
		return cpuSample{},
			errors.New("无法读取 CPU")
	}

	fields := strings.Fields(scanner.Text())

	if len(fields) < 5 ||
		fields[0] != "cpu" {
		return cpuSample{},
			errors.New("CPU 格式无效")
	}

	values := make([]uint64, 0)

	for _, field := range fields[1:] {
		value, err := strconv.ParseUint(
			field,
			10,
			64,
		)

		if err != nil {
			return cpuSample{}, err
		}

		values = append(values, value)
	}

	var total uint64

	for _, value := range values {
		total += value
	}

	idle := values[3]

	if len(values) > 4 {
		idle += values[4]
	}

	return cpuSample{
		Idle:  idle,
		Total: total,
	}, nil
}

func cpuUsage(
	first cpuSample,
	second cpuSample,
) float64 {
	if second.Total <= first.Total {
		return 0
	}

	total := second.Total - first.Total
	idle := second.Idle - first.Idle

	if idle > total {
		idle = total
	}

	return 100 *
		float64(total-idle) /
		float64(total)
}

func readMemory() (int64, int64, error) {
	file, err := os.Open("/proc/meminfo")

	if err != nil {
		return 0, 0, err
	}

	defer file.Close()

	values := make(map[string]int64)
	scanner := bufio.NewScanner(file)

	for scanner.Scan() {
		fields := strings.Fields(
			scanner.Text(),
		)

		if len(fields) < 2 {
			continue
		}

		value, err := strconv.ParseInt(
			fields[1],
			10,
			64,
		)

		if err == nil {
			values[
				strings.TrimSuffix(
					fields[0],
					":",
				),
			] = value * 1024
		}
	}

	total := values["MemTotal"]
	available := values["MemAvailable"]

	if available == 0 {
		available =
			values["MemFree"] +
				values["Buffers"] +
				values["Cached"]
	}

	used := total - available

	if used < 0 {
		used = 0
	}

	return total, used, scanner.Err()
}

func readDisk(path string) (int64, int64, error) {
	var stat syscall.Statfs_t

	if err := syscall.Statfs(
		path,
		&stat,
	); err != nil {
		return 0, 0, err
	}

	total := int64(stat.Blocks) *
		int64(stat.Bsize)

	available := int64(stat.Bavail) *
		int64(stat.Bsize)

	return total, total - available, nil
}

func detectInterface() string {
	file, err := os.Open("/proc/net/route")

	if err == nil {
		defer file.Close()

		scanner := bufio.NewScanner(file)

		for scanner.Scan() {
			fields := strings.Fields(
				scanner.Text(),
			)

			if len(fields) >= 4 &&
				fields[1] == "00000000" {
				return fields[0]
			}
		}
	}

	file, err = os.Open("/proc/net/dev")

	if err != nil {
		return ""
	}

	defer file.Close()

	scanner := bufio.NewScanner(file)

	for scanner.Scan() {
		line := scanner.Text()

		if !strings.Contains(line, ":") {
			continue
		}

		name := strings.TrimSpace(
			strings.SplitN(
				line,
				":",
				2,
			)[0],
		)

		if name != "lo" &&
			!strings.HasPrefix(
				name,
				"docker",
			) {
			return name
		}
	}

	return ""
}

func readNetwork(
	interfaceName string,
) (networkSample, error) {
	file, err := os.Open("/proc/net/dev")

	if err != nil {
		return networkSample{}, err
	}

	defer file.Close()

	scanner := bufio.NewScanner(file)

	for scanner.Scan() {
		line := scanner.Text()

		if !strings.Contains(line, ":") {
			continue
		}

		parts := strings.SplitN(line, ":", 2)
		name := strings.TrimSpace(parts[0])

		if name != interfaceName {
			continue
		}

		fields := strings.Fields(parts[1])

		if len(fields) < 16 {
			break
		}

		received, error1 :=
			strconv.ParseUint(
				fields[0],
				10,
				64,
			)

		transmitted, error2 :=
			strconv.ParseUint(
				fields[8],
				10,
				64,
			)

		if error1 != nil ||
			error2 != nil {
			break
		}

		return networkSample{
			Received:    received,
			Transmitted: transmitted,
		}, nil
	}

	return networkSample{},
		errors.New("找不到网络接口")
}

func readUptime() int64 {
	content, err := os.ReadFile("/proc/uptime")

	if err != nil {
		return 0
	}

	fields := strings.Fields(string(content))

	if len(fields) == 0 {
		return 0
	}

	seconds, err := strconv.ParseFloat(
		fields[0],
		64,
	)

	if err != nil {
		return 0
	}

	return int64(seconds)
}

func collect(
	ctx context.Context,
	configuration configuration,
) (report, error) {
	osRelease := readOSRelease()

	interfaceName :=
		configuration.NetworkInterface

	if interfaceName == "" {
		interfaceName = detectInterface()
	}

	firstCPU, err := readCPU()

	if err != nil {
		return report{}, err
	}

	firstNetwork, networkError :=
		readNetwork(interfaceName)

	startedAt := time.Now()
	timer := time.NewTimer(time.Second)

	defer timer.Stop()

	select {
	case <-ctx.Done():
		return report{}, ctx.Err()

	case <-timer.C:
	}

	secondCPU, err := readCPU()

	if err != nil {
		return report{}, err
	}

	elapsed := time.Since(
		startedAt,
	).Seconds()

	download := 0.0
	upload := 0.0

	if networkError == nil {
		if secondNetwork, err :=
			readNetwork(interfaceName);
			err == nil && elapsed > 0 {
			if secondNetwork.Received >=
				firstNetwork.Received {
				download =
					float64(
						secondNetwork.Received-
							firstNetwork.Received,
					) / elapsed
			}

			if secondNetwork.Transmitted >=
				firstNetwork.Transmitted {
				upload =
					float64(
						secondNetwork.Transmitted-
							firstNetwork.Transmitted,
					) / elapsed
			}
		}
	}

	memoryTotal, memoryUsed, err :=
		readMemory()

	if err != nil {
		return report{}, err
	}

	diskTotal, diskUsed, err :=
		readDisk(
			configuration.RootFilesystem,
		)

	if err != nil {
		return report{}, err
	}

	return report{
		OSID: strings.ToLower(
			osRelease["ID"],
		),

		OSName:       osRelease["NAME"],
		OSVersion:    osRelease["VERSION_ID"],
		Architecture: runtime.GOARCH,

		CPUCores: runtime.NumCPU(),
		CPUUsage: cpuUsage(
			firstCPU,
			secondCPU,
		),

		MemoryTotalBytes: memoryTotal,
		MemoryUsedBytes:  memoryUsed,

		DiskTotalBytes: diskTotal,
		DiskUsedBytes:  diskUsed,

		NetworkDownloadBps: download,
		NetworkUploadBps:   upload,

		UptimeSeconds: readUptime(),
	}, nil
}

func send(
	ctx context.Context,
	client *http.Client,
	configuration configuration,
) error {
	payload, err := collect(
		ctx,
		configuration,
	)

	if err != nil {
		return err
	}

	body, err := json.Marshal(payload)

	if err != nil {
		return err
	}

	request, err := http.NewRequestWithContext(
		ctx,
		http.MethodPost,
		configuration.APIURL+
			"/api/v1/agent/report",
		bytes.NewReader(body),
	)

	if err != nil {
		return err
	}

	request.Header.Set(
		"Authorization",
		"Bearer "+configuration.AgentToken,
	)

	request.Header.Set(
		"Content-Type",
		"application/json",
	)

	request.Header.Set(
		"User-Agent",
		"VPS-Board-Agent/4.0",
	)

	response, err := client.Do(request)

	if err != nil {
		return err
	}

	defer response.Body.Close()

	if response.StatusCode !=
		http.StatusNoContent {
		message, _ := io.ReadAll(
			io.LimitReader(
				response.Body,
				512,
			),
		)

		return fmt.Errorf(
			"HTTP %d %s",
			response.StatusCode,
			message,
		)
	}

	return nil
}

func main() {
	configuration, err := loadConfig()

	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}

	ctx, cancel := signal.NotifyContext(
		context.Background(),
		syscall.SIGINT,
		syscall.SIGTERM,
	)

	defer cancel()

	client := &http.Client{
		Timeout: configuration.RequestTimeout,
	}

	for {
		startedAt := time.Now()

		if err := send(
			ctx,
			client,
			configuration,
		); err != nil &&
			!errors.Is(
				err,
				context.Canceled,
			) {
			fmt.Fprintf(
				os.Stderr,
				"Agent 上报失败：%T\n",
				err,
			)
		}

		wait := configuration.Interval -
			time.Since(startedAt)

		if wait < time.Second {
			wait = time.Second
		}

		timer := time.NewTimer(wait)

		select {
		case <-ctx.Done():
			timer.Stop()
			return

		case <-timer.C:
		}
	}
}