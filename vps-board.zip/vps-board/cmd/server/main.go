package main

import (
	"bufio"
	"context"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"database/sql"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"math"
	"net"
	"net/http"
	"net/netip"
	"net/url"
	"os"
	"os/signal"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"

	_ "modernc.org/sqlite"
)

const (
	slaRetention     = 30 * 24 * time.Hour
	metricsRetention = 24 * time.Hour
)

type config struct {
	ListenAddress string
	DatabasePath  string
	AdminToken    string
	IPHashKey     string
	IPInfoAPIBase string

	AllowedOrigins map[string]struct{}

	NetworkTTL             time.Duration
	NetworkFailureCooldown time.Duration
	IPInfoRequestInterval  time.Duration
	OfflineAfter           time.Duration
}

type machineInput struct {
	Name     string `json:"name"`
	Provider string `json:"provider"`
}

type agentReport struct {
	OSID         string `json:"osId"`
	OSName       string `json:"osName"`
	OSVersion    string `json:"osVersion"`
	Architecture string `json:"architecture"`

	CPUCores int     `json:"cpuCores"`
	CPUUsage float64 `json:"cpuUsage"`

	MemoryTotalBytes int64 `json:"memoryTotalBytes"`
	MemoryUsedBytes  int64 `json:"memoryUsedBytes"`

	DiskTotalBytes int64 `json:"diskTotalBytes"`
	DiskUsedBytes  int64 `json:"diskUsedBytes"`

	NetworkDownloadBps float64 `json:"networkDownloadBps"`
	NetworkUploadBps   float64 `json:"networkUploadBps"`

	UptimeSeconds int64 `json:"uptimeSeconds"`
}

type networkPublic struct {
	ISP          string `json:"isp"`
	Organization string `json:"organization"`
	ASN          string `json:"asn"`
	ASName       string `json:"asName"`
	Type         string `json:"type"`

	City        string   `json:"city"`
	Region      string   `json:"region"`
	CountryCode string   `json:"countryCode"`
	Latitude    *float64 `json:"latitude"`
	Longitude   *float64 `json:"longitude"`

	RiskScore  int    `json:"riskScore"`
	RiskSource string `json:"riskSource"`

	Hosting bool `json:"hosting"`
	Proxy   bool `json:"proxy"`
	VPN     bool `json:"vpn"`
	Tor     bool `json:"tor"`
	Relay   bool `json:"relay"`

	CheckedAt string `json:"checkedAt"`
}

type systemPublic struct {
	OSID          string `json:"osId"`
	OSName        string `json:"osName"`
	OSVersion     string `json:"osVersion"`
	Architecture  string `json:"architecture"`
	UptimeSeconds int64  `json:"uptimeSeconds"`
}

type metricsPublic struct {
	CPUCores int     `json:"cpuCores"`
	CPUUsage float64 `json:"cpuUsage"`

	MemoryTotalBytes int64   `json:"memoryTotalBytes"`
	MemoryUsedBytes  int64   `json:"memoryUsedBytes"`
	MemoryUsage      float64 `json:"memoryUsage"`

	DiskTotalBytes int64   `json:"diskTotalBytes"`
	DiskUsedBytes  int64   `json:"diskUsedBytes"`
	DiskUsage      float64 `json:"diskUsage"`

	NetworkDownloadBps float64 `json:"networkDownloadBps"`
	NetworkUploadBps   float64 `json:"networkUploadBps"`

	TotalOnlineSeconds int64  `json:"totalOnlineSeconds"`
	LastSeenAt         string `json:"lastSeenAt"`
}

type machinePublic struct {
	ID       string `json:"id"`
	Name     string `json:"name"`
	Provider string `json:"provider"`
	Status   string `json:"status"`

	Network *networkPublic `json:"network"`
	System  systemPublic   `json:"system"`
	Metrics metricsPublic  `json:"metrics"`

	FirstSeenAt string `json:"firstSeenAt"`
	CreatedAt   string `json:"createdAt"`
	UpdatedAt   string `json:"updatedAt"`
}

type machineRecord struct {
	ID       string
	Name     string
	Provider string

	ISP          string
	Organization string
	ASN          string
	ASName       string
	NetworkType  string

	City        string
	Region      string
	CountryCode string
	Latitude    sql.NullFloat64
	Longitude   sql.NullFloat64
	RiskScore   int

	Hosting int
	Proxy   int
	VPN     int
	Tor     int
	Relay   int

	NetworkCheckedAt string

	OSID         string
	OSName       string
	OSVersion    string
	Architecture string

	CPUCores int
	CPUUsage float64

	MemoryTotalBytes int64
	MemoryUsedBytes  int64
	MemoryUsage      float64

	DiskTotalBytes int64
	DiskUsedBytes  int64
	DiskUsage      float64

	NetworkDownloadBps float64
	NetworkUploadBps   float64

	UptimeSeconds      int64
	TotalOnlineSeconds int64

	LastSeenAt string
	FirstSeenAt string
	CreatedAt  string
	UpdatedAt  string
}

type authenticatedAgent struct {
	MachineID        string
	AgentTokenHash   string
	IPHash           string
	NetworkCheckedAt string
	LastSeenAt       string
}

type historyPoint struct {
	Time int64 `json:"time"`

	Online bool `json:"online"`

	CPUUsage    float64 `json:"cpuUsage"`
	MemoryUsage float64 `json:"memoryUsage"`
	DiskUsage   float64 `json:"diskUsage"`

	NetworkDownloadBps float64 `json:"networkDownloadBps"`
	NetworkUploadBps   float64 `json:"networkUploadBps"`
}

type slaResponse struct {
	Days            int     `json:"days"`
	OnlineMinutes   int64   `json:"onlineMinutes"`
	OfflineMinutes  int64   `json:"offlineMinutes"`
	ObservedMinutes int64   `json:"observedMinutes"`
	UnknownMinutes  int64   `json:"unknownMinutes"`
	SLA             float64 `json:"sla"`
}

type ipInfoASN struct {
	ASN  string `json:"asn"`
	Name string `json:"name"`
	Type string `json:"type"`
}

type ipInfoCompany struct {
	Name string `json:"name"`
	Type string `json:"type"`
}

type ipInfoPrivacy struct {
	VPN     bool `json:"vpn"`
	Proxy   bool `json:"proxy"`
	Tor     bool `json:"tor"`
	Relay   bool `json:"relay"`
	Hosting bool `json:"hosting"`
}

type ipInfoData struct {
	IP      string `json:"ip"`
	City    string `json:"city"`
	Region  string `json:"region"`
	Country string `json:"country"`
	Loc     string `json:"loc"`
	Org     string `json:"org"`

	ASN     ipInfoASN     `json:"asn"`
	Company ipInfoCompany `json:"company"`
	Privacy ipInfoPrivacy `json:"privacy"`
}

type ipInfoWidgetResponse struct {
	Input string      `json:"input"`
	Data  *ipInfoData `json:"data"`
}

type networkResult struct {
	ISP          string
	Organization string
	ASN          string
	ASName       string
	NetworkType  string

	City        string
	Region      string
	CountryCode string
	Latitude    *float64
	Longitude   *float64
	RiskScore   int

	Hosting bool
	Proxy   bool
	VPN     bool
	Tor     bool
	Relay   bool

	CheckedAt string
}

type networkJob struct {
	IP     string
	IPHash string
}

type event struct {
	Name string
	Data any
}

type broker struct {
	mutex   sync.Mutex
	clients map[chan event]struct{}
}

type app struct {
	config config
	db     *sql.DB

	httpClient *http.Client
	broker     *broker

	networkQueue chan networkJob

	networkMutex     sync.Mutex
	pendingNetworks  map[string]struct{}
	networkCooldowns map[string]time.Time
}

type rowScanner interface {
	Scan(dest ...any) error
}

const machineColumns = `
	id,
	name,
	provider,

	COALESCE(isp, ''),
	COALESCE(organization, ''),
	COALESCE(asn, ''),
	COALESCE(as_name, ''),
	COALESCE(network_type, ''),

	COALESCE(city, ''),
	COALESCE(region, ''),
	COALESCE(country, ''),
	latitude,
	longitude,
	COALESCE(risk_score, 0),

	COALESCE(hosting, 0),
	COALESCE(proxy, 0),
	COALESCE(vpn, 0),
	COALESCE(tor, 0),
	COALESCE(relay, 0),

	COALESCE(network_checked_at, ''),

	COALESCE(os_id, ''),
	COALESCE(os_name, ''),
	COALESCE(os_version, ''),
	COALESCE(architecture, ''),

	COALESCE(cpu_cores, 0),
	COALESCE(cpu_usage, 0),

	COALESCE(memory_total_bytes, 0),
	COALESCE(memory_used_bytes, 0),
	COALESCE(memory_usage, 0),

	COALESCE(disk_total_bytes, 0),
	COALESCE(disk_used_bytes, 0),
	COALESCE(disk_usage, 0),

	COALESCE(network_download_bps, 0),
	COALESCE(network_upload_bps, 0),

	COALESCE(uptime_seconds, 0),
	COALESCE(total_online_seconds, 0),

	COALESCE(last_seen_at, ''),
	COALESCE(first_seen_at, ''),
	created_at,
	updated_at
`

func env(name, fallback string) string {
	value := strings.TrimSpace(os.Getenv(name))

	if value == "" {
		return fallback
	}

	return value
}

func requiredEnv(name string) string {
	value := strings.TrimSpace(os.Getenv(name))

	if value == "" {
		log.Fatalf("缺少环境变量：%s", name)
	}

	return value
}

func envInt(name string, fallback int) int {
	value, err := strconv.Atoi(env(name, ""))

	if err != nil {
		return fallback
	}

	return value
}

func loadConfig() config {
	adminToken := requiredEnv("ADMIN_TOKEN")
	ipHashKey := requiredEnv("IP_HASH_KEY")

	if len(adminToken) < 32 || len(ipHashKey) < 32 {
		log.Fatal("ADMIN_TOKEN 和 IP_HASH_KEY 长度不能小于 32")
	}

	origins := make(map[string]struct{})

	for _, origin := range strings.Split(
		env("ALLOWED_ORIGINS", ""),
		",",
	) {
		origin = strings.TrimSpace(origin)

		if origin != "" {
			origins[origin] = struct{}{}
		}
	}

	return config{
		ListenAddress: env(
			"LISTEN_ADDRESS",
			"127.0.0.1:8080",
		),

		DatabasePath: env(
			"DATABASE_PATH",
			"/var/lib/vps-board/board.db",
		),

		AdminToken: adminToken,
		IPHashKey:  ipHashKey,

		IPInfoAPIBase: strings.TrimRight(
			env(
				"IPINFO_API_BASE",
				"https://ipinfo.io/widget/demo",
			),
			"/",
		),

		AllowedOrigins: origins,

		NetworkTTL: time.Duration(
			envInt("NETWORK_TTL_SECONDS", 86400),
		) * time.Second,

		NetworkFailureCooldown: time.Duration(
			envInt(
				"NETWORK_FAILURE_COOLDOWN_SECONDS",
				600,
			),
		) * time.Second,

		IPInfoRequestInterval: time.Duration(
			envInt("IPINFO_REQUEST_INTERVAL_MS", 1200),
		) * time.Millisecond,

		OfflineAfter: time.Duration(
			envInt("OFFLINE_AFTER_SECONDS", 20),
		) * time.Second,
	}
}

func newBroker() *broker {
	return &broker{
		clients: make(map[chan event]struct{}),
	}
}

func (b *broker) subscribe() chan event {
	channel := make(chan event, 32)

	b.mutex.Lock()
	b.clients[channel] = struct{}{}
	b.mutex.Unlock()

	return channel
}

func (b *broker) unsubscribe(channel chan event) {
	b.mutex.Lock()

	if _, exists := b.clients[channel]; exists {
		delete(b.clients, channel)
		close(channel)
	}

	b.mutex.Unlock()
}

func (b *broker) publish(message event) {
	b.mutex.Lock()
	defer b.mutex.Unlock()

	for channel := range b.clients {
		select {
		case channel <- message:
		default:
		}
	}
}

func newApp(configuration config) (*app, error) {
	if err := os.MkdirAll(
		filepath.Dir(configuration.DatabasePath),
		0700,
	); err != nil {
		return nil, err
	}

	database, err := sql.Open(
		"sqlite",
		configuration.DatabasePath,
	)

	if err != nil {
		return nil, err
	}

	database.SetMaxOpenConns(1)
	database.SetMaxIdleConns(1)

	instance := &app{
		config: configuration,
		db:     database,

		httpClient: &http.Client{
			Timeout: 12 * time.Second,
		},

		broker: newBroker(),

		networkQueue: make(chan networkJob, 100),

		pendingNetworks:  make(map[string]struct{}),
		networkCooldowns: make(map[string]time.Time),
	}

	if err := instance.initializeDatabase(); err != nil {
		database.Close()
		return nil, err
	}

	return instance, nil
}

func (a *app) initializeDatabase() error {
	statements := []string{
		`PRAGMA journal_mode=WAL`,
		`PRAGMA foreign_keys=ON`,
		`PRAGMA busy_timeout=5000`,

		`
		CREATE TABLE IF NOT EXISTS machines (
			id TEXT PRIMARY KEY,
			name TEXT NOT NULL,
			provider TEXT NOT NULL DEFAULT '',
			agent_token_hash TEXT NOT NULL UNIQUE,
			ip_hash TEXT,

			isp TEXT,
			organization TEXT,
			asn TEXT,
			as_name TEXT,
			network_type TEXT,

			city TEXT,
			region TEXT,
			country TEXT,
			latitude REAL,
			longitude REAL,
			risk_score INTEGER NOT NULL DEFAULT 0,

			hosting INTEGER,
			proxy INTEGER,
			vpn INTEGER,
			tor INTEGER,
			relay INTEGER,
			network_checked_at TEXT,

			os_id TEXT,
			os_name TEXT,
			os_version TEXT,
			architecture TEXT,

			cpu_cores INTEGER NOT NULL DEFAULT 0,
			cpu_usage REAL NOT NULL DEFAULT 0,

			memory_total_bytes INTEGER NOT NULL DEFAULT 0,
			memory_used_bytes INTEGER NOT NULL DEFAULT 0,
			memory_usage REAL NOT NULL DEFAULT 0,

			disk_total_bytes INTEGER NOT NULL DEFAULT 0,
			disk_used_bytes INTEGER NOT NULL DEFAULT 0,
			disk_usage REAL NOT NULL DEFAULT 0,

			network_download_bps REAL NOT NULL DEFAULT 0,
			network_upload_bps REAL NOT NULL DEFAULT 0,

			uptime_seconds INTEGER NOT NULL DEFAULT 0,
			total_online_seconds INTEGER NOT NULL DEFAULT 0,

			last_seen_at TEXT,
			first_seen_at TEXT,
			created_at TEXT NOT NULL,
			updated_at TEXT NOT NULL
		)
		`,

		`
		CREATE TABLE IF NOT EXISTS network_cache (
			ip_hash TEXT PRIMARY KEY,

			isp TEXT NOT NULL DEFAULT '',
			organization TEXT NOT NULL DEFAULT '',
			asn TEXT NOT NULL DEFAULT '',
			as_name TEXT NOT NULL DEFAULT '',
			network_type TEXT NOT NULL DEFAULT 'UNKNOWN',

			city TEXT NOT NULL DEFAULT '',
			region TEXT NOT NULL DEFAULT '',
			country TEXT NOT NULL DEFAULT '',
			latitude REAL,
			longitude REAL,
			risk_score INTEGER NOT NULL DEFAULT 0,

			hosting INTEGER NOT NULL DEFAULT 0,
			proxy INTEGER NOT NULL DEFAULT 0,
			vpn INTEGER NOT NULL DEFAULT 0,
			tor INTEGER NOT NULL DEFAULT 0,
			relay INTEGER NOT NULL DEFAULT 0,

			checked_at TEXT NOT NULL
		)
		`,

		`
		CREATE TABLE IF NOT EXISTS availability_history (
			machine_id TEXT NOT NULL,
			bucket_at INTEGER NOT NULL,
			online INTEGER NOT NULL,

			PRIMARY KEY (machine_id, bucket_at),
			FOREIGN KEY (machine_id)
				REFERENCES machines(id)
				ON DELETE CASCADE
		)
		`,

		`
		CREATE TABLE IF NOT EXISTS metrics_history (
			machine_id TEXT NOT NULL,
			bucket_at INTEGER NOT NULL,
			online INTEGER NOT NULL,

			cpu_usage REAL NOT NULL DEFAULT 0,
			memory_usage REAL NOT NULL DEFAULT 0,
			disk_usage REAL NOT NULL DEFAULT 0,

			network_download_bps REAL NOT NULL DEFAULT 0,
			network_upload_bps REAL NOT NULL DEFAULT 0,

			PRIMARY KEY (machine_id, bucket_at),
			FOREIGN KEY (machine_id)
				REFERENCES machines(id)
				ON DELETE CASCADE
		)
		`,
	}

	for _, statement := range statements {
		if _, err := a.db.Exec(statement); err != nil {
			return err
		}
	}

	machineColumns := map[string]string{
		"city":                   "TEXT",
		"region":                 "TEXT",
		"country":                "TEXT",
		"latitude":               "REAL",
		"longitude":              "REAL",
		"risk_score":             "INTEGER NOT NULL DEFAULT 0",
		"architecture":           "TEXT",
		"uptime_seconds":         "INTEGER NOT NULL DEFAULT 0",
		"total_online_seconds":   "INTEGER NOT NULL DEFAULT 0",
		"first_seen_at":          "TEXT",
		"network_download_bps":   "REAL NOT NULL DEFAULT 0",
		"network_upload_bps":     "REAL NOT NULL DEFAULT 0",
	}

	cacheColumns := map[string]string{
		"city":       "TEXT NOT NULL DEFAULT ''",
		"region":     "TEXT NOT NULL DEFAULT ''",
		"country":    "TEXT NOT NULL DEFAULT ''",
		"latitude":   "REAL",
		"longitude":  "REAL",
		"risk_score": "INTEGER NOT NULL DEFAULT 0",
	}

	locationChanged := false

	for name, definition := range machineColumns {
		added, err := a.ensureColumn(
			"machines",
			name,
			definition,
		)

		if err != nil {
			return err
		}

		if added &&
			(name == "latitude" ||
				name == "longitude") {
			locationChanged = true
		}
	}

	for name, definition := range cacheColumns {
		added, err := a.ensureColumn(
			"network_cache",
			name,
			definition,
		)

		if err != nil {
			return err
		}

		if added {
			locationChanged = true
		}
	}

	indexes := []string{
		`
		CREATE INDEX IF NOT EXISTS
		idx_machines_ip_hash
		ON machines(ip_hash)
		`,

		`
		CREATE INDEX IF NOT EXISTS
		idx_availability_machine_time
		ON availability_history(machine_id, bucket_at)
		`,

		`
		CREATE INDEX IF NOT EXISTS
		idx_metrics_machine_time
		ON metrics_history(machine_id, bucket_at)
		`,
	}

	for _, statement := range indexes {
		if _, err := a.db.Exec(statement); err != nil {
			return err
		}
	}

	if locationChanged {
		if _, err := a.db.Exec(
			`DELETE FROM network_cache`,
		); err != nil {
			return err
		}

		if _, err := a.db.Exec(`
			UPDATE machines
			SET
				latitude = NULL,
				longitude = NULL,
				network_checked_at = NULL
		`); err != nil {
			return err
		}
	}

	return nil
}

func (a *app) ensureColumn(
	table string,
	column string,
	definition string,
) (bool, error) {
	if table != "machines" &&
		table != "network_cache" {
		return false, errors.New("非法表名")
	}

	rows, err := a.db.Query(
		"PRAGMA table_info(" + table + ")",
	)

	if err != nil {
		return false, err
	}

	exists := false

	for rows.Next() {
		var id int
		var name string
		var dataType string
		var notNull int
		var defaultValue any
		var primaryKey int

		if err := rows.Scan(
			&id,
			&name,
			&dataType,
			&notNull,
			&defaultValue,
			&primaryKey,
		); err != nil {
			rows.Close()
			return false, err
		}

		if name == column {
			exists = true
		}
	}

	rows.Close()

	if exists {
		return false, nil
	}

	_, err = a.db.Exec(
		fmt.Sprintf(
			"ALTER TABLE %s ADD COLUMN %s %s",
			table,
			column,
			definition,
		),
	)

	return err == nil, err
}

func nowString() string {
	return time.Now().UTC().Format(time.RFC3339Nano)
}

func parseTime(value string) (time.Time, bool) {
	parsed, err := time.Parse(
		time.RFC3339Nano,
		value,
	)

	if err != nil {
		return time.Time{}, false
	}

	return parsed, true
}

func isFresh(
	value string,
	maximumAge time.Duration,
) bool {
	parsed, ok := parseTime(value)

	if !ok {
		return false
	}

	age := time.Since(parsed)

	return age >= 0 && age <= maximumAge
}

func clamp(value, minimum, maximum float64) float64 {
	return math.Min(
		maximum,
		math.Max(minimum, value),
	)
}

func clampInt(value, minimum, maximum int) int {
	if value < minimum {
		return minimum
	}

	if value > maximum {
		return maximum
	}

	return value
}

func trimLimit(value string, maximum int) string {
	value = strings.TrimSpace(value)
	runes := []rune(value)

	if len(runes) > maximum {
		runes = runes[:maximum]
	}

	return string(runes)
}

func normalizeCountry(value string) string {
	value = strings.ToUpper(
		strings.TrimSpace(value),
	)

	if len(value) != 2 {
		return ""
	}

	for _, character := range value {
		if character < 'A' ||
			character > 'Z' {
			return ""
		}
	}

	return value
}

func randomHex(length int) (string, error) {
	buffer := make([]byte, length)

	if _, err := rand.Read(buffer); err != nil {
		return "", err
	}

	return hex.EncodeToString(buffer), nil
}

func randomSecret(length int) (string, error) {
	buffer := make([]byte, length)

	if _, err := rand.Read(buffer); err != nil {
		return "", err
	}

	return base64.RawURLEncoding.EncodeToString(
		buffer,
	), nil
}

func hashAgentSecret(secret string) string {
	digest := sha256.Sum256([]byte(secret))

	return hex.EncodeToString(digest[:])
}

func constantCompare(left, right string) bool {
	return subtle.ConstantTimeCompare(
		[]byte(left),
		[]byte(right),
	) == 1
}

func extractBearer(request *http.Request) string {
	header := strings.TrimSpace(
		request.Header.Get("Authorization"),
	)

	if !strings.HasPrefix(
		header,
		"Bearer ",
	) {
		return ""
	}

	return strings.TrimSpace(
		strings.TrimPrefix(
			header,
			"Bearer ",
		),
	)
}

func writeJSON(
	writer http.ResponseWriter,
	status int,
	value any,
) {
	writer.Header().Set(
		"Content-Type",
		"application/json; charset=utf-8",
	)

	writer.WriteHeader(status)

	_ = json.NewEncoder(writer).Encode(value)
}

func writeError(
	writer http.ResponseWriter,
	status int,
	message string,
) {
	writeJSON(
		writer,
		status,
		map[string]string{
			"detail": message,
		},
	)
}

func decodeJSON(
	writer http.ResponseWriter,
	request *http.Request,
	target any,
) error {
	request.Body = http.MaxBytesReader(
		writer,
		request.Body,
		1024*1024,
	)

	decoder := json.NewDecoder(request.Body)
	decoder.DisallowUnknownFields()

	if err := decoder.Decode(target); err != nil {
		return err
	}

	var extra any

	if err := decoder.Decode(&extra); !errors.Is(
		err,
		io.EOF,
	) {
		return errors.New("JSON 内容过多")
	}

	return nil
}

func nullableFloat(value *float64) any {
	if value == nil {
		return nil
	}

	return *value
}

func scanMachine(
	scanner rowScanner,
) (machineRecord, error) {
	var record machineRecord

	err := scanner.Scan(
		&record.ID,
		&record.Name,
		&record.Provider,

		&record.ISP,
		&record.Organization,
		&record.ASN,
		&record.ASName,
		&record.NetworkType,

		&record.City,
		&record.Region,
		&record.CountryCode,
		&record.Latitude,
		&record.Longitude,
		&record.RiskScore,

		&record.Hosting,
		&record.Proxy,
		&record.VPN,
		&record.Tor,
		&record.Relay,

		&record.NetworkCheckedAt,

		&record.OSID,
		&record.OSName,
		&record.OSVersion,
		&record.Architecture,

		&record.CPUCores,
		&record.CPUUsage,

		&record.MemoryTotalBytes,
		&record.MemoryUsedBytes,
		&record.MemoryUsage,

		&record.DiskTotalBytes,
		&record.DiskUsedBytes,
		&record.DiskUsage,

		&record.NetworkDownloadBps,
		&record.NetworkUploadBps,

		&record.UptimeSeconds,
		&record.TotalOnlineSeconds,

		&record.LastSeenAt,
		&record.FirstSeenAt,
		&record.CreatedAt,
		&record.UpdatedAt,
	)

	return record, err
}

func (a *app) recordToPublic(
	record machineRecord,
) machinePublic {
	status := "offline"

	if isFresh(
		record.LastSeenAt,
		a.config.OfflineAfter,
	) {
		status = "online"
	}

	var network *networkPublic

	if record.NetworkCheckedAt != "" {
		network = &networkPublic{
			ISP:          record.ISP,
			Organization: record.Organization,
			ASN:          record.ASN,
			ASName:       record.ASName,
			Type:         record.NetworkType,

			City:        record.City,
			Region:      record.Region,
			CountryCode: normalizeCountry(
				record.CountryCode,
			),

			RiskScore: clampInt(
				record.RiskScore,
				0,
				100,
			),

			RiskSource: "IPinfo",

			Hosting: record.Hosting == 1,
			Proxy:   record.Proxy == 1,
			VPN:     record.VPN == 1,
			Tor:     record.Tor == 1,
			Relay:   record.Relay == 1,

			CheckedAt: record.NetworkCheckedAt,
		}

		if record.Latitude.Valid {
			latitude := record.Latitude.Float64
			network.Latitude = &latitude
		}

		if record.Longitude.Valid {
			longitude := record.Longitude.Float64
			network.Longitude = &longitude
		}
	}

	osID := record.OSID
	osName := record.OSName

	if osID == "" {
		osID = "linux"
	}

	if osName == "" {
		osName = "Linux"
	}

	return machinePublic{
		ID:       record.ID,
		Name:     record.Name,
		Provider: record.Provider,
		Status:   status,

		Network: network,

		System: systemPublic{
			OSID:          osID,
			OSName:        osName,
			OSVersion:     record.OSVersion,
			Architecture:  record.Architecture,
			UptimeSeconds: record.UptimeSeconds,
		},

		Metrics: metricsPublic{
			CPUCores: record.CPUCores,

			CPUUsage: math.Round(
				record.CPUUsage*10,
			) / 10,

			MemoryTotalBytes: record.MemoryTotalBytes,
			MemoryUsedBytes:  record.MemoryUsedBytes,

			MemoryUsage: math.Round(
				record.MemoryUsage*10,
			) / 10,

			DiskTotalBytes: record.DiskTotalBytes,
			DiskUsedBytes:  record.DiskUsedBytes,

			DiskUsage: math.Round(
				record.DiskUsage*10,
			) / 10,

			NetworkDownloadBps: math.Round(
				record.NetworkDownloadBps,
			),

			NetworkUploadBps: math.Round(
				record.NetworkUploadBps,
			),

			TotalOnlineSeconds: record.TotalOnlineSeconds,
			LastSeenAt:         record.LastSeenAt,
		},

		FirstSeenAt: record.FirstSeenAt,
		CreatedAt:   record.CreatedAt,
		UpdatedAt:   record.UpdatedAt,
	}
}

func (a *app) listMachines() (
	[]machinePublic,
	error,
) {
	rows, err := a.db.Query(`
		SELECT ` + machineColumns + `
		FROM machines
		ORDER BY created_at ASC
	`)

	if err != nil {
		return nil, err
	}

	defer rows.Close()

	result := make([]machinePublic, 0)

	for rows.Next() {
		record, err := scanMachine(rows)

		if err != nil {
			return nil, err
		}

		result = append(
			result,
			a.recordToPublic(record),
		)
	}

	return result, rows.Err()
}

func (a *app) getMachine(
	machineID string,
) (machinePublic, error) {
	record, err := scanMachine(
		a.db.QueryRow(`
			SELECT `+machineColumns+`
			FROM machines
			WHERE id = ?
		`, machineID),
	)

	if err != nil {
		return machinePublic{}, err
	}

	return a.recordToPublic(record), nil
}

func (a *app) requireAdmin(
	writer http.ResponseWriter,
	request *http.Request,
) bool {
	if !constantCompare(
		extractBearer(request),
		a.config.AdminToken,
	) {
		writeError(
			writer,
			http.StatusUnauthorized,
			"管理员密钥无效",
		)

		return false
	}

	return true
}

func (a *app) authenticateAgent(
	request *http.Request,
) (authenticatedAgent, error) {
	token := extractBearer(request)
	parts := strings.SplitN(token, ".", 2)

	if len(parts) != 2 {
		return authenticatedAgent{},
			errors.New("Agent Token 无效")
	}

	var result authenticatedAgent

	err := a.db.QueryRow(`
		SELECT
			id,
			agent_token_hash,
			COALESCE(ip_hash, ''),
			COALESCE(network_checked_at, ''),
			COALESCE(last_seen_at, '')
		FROM machines
		WHERE id = ?
	`, parts[0]).Scan(
		&result.MachineID,
		&result.AgentTokenHash,
		&result.IPHash,
		&result.NetworkCheckedAt,
		&result.LastSeenAt,
	)

	if err != nil ||
		!constantCompare(
			hashAgentSecret(parts[1]),
			result.AgentTokenHash,
		) {
		return authenticatedAgent{},
			errors.New("Agent Token 无效")
	}

	return result, nil
}

func (a *app) middleware(
	next http.Handler,
) http.Handler {
	return http.HandlerFunc(
		func(
			writer http.ResponseWriter,
			request *http.Request,
		) {
			origin := strings.TrimSpace(
				request.Header.Get("Origin"),
			)

			if origin != "" {
				if _, allowed :=
					a.config.AllowedOrigins[origin];
					!allowed {
					writeError(
						writer,
						http.StatusForbidden,
						"不允许的网页来源",
					)

					return
				}

				writer.Header().Set(
					"Access-Control-Allow-Origin",
					origin,
				)

				writer.Header().Set(
					"Vary",
					"Origin",
				)

				writer.Header().Set(
					"Access-Control-Allow-Methods",
					"GET, POST, PUT, DELETE, OPTIONS",
				)

				writer.Header().Set(
					"Access-Control-Allow-Headers",
					"Authorization, Content-Type",
				)
			}

			writer.Header().Set(
				"X-Content-Type-Options",
				"nosniff",
			)

			writer.Header().Set(
				"X-Frame-Options",
				"DENY",
			)

			writer.Header().Set(
				"Referrer-Policy",
				"no-referrer",
			)

			if strings.HasPrefix(
				request.URL.Path,
				"/api/",
			) {
				writer.Header().Set(
					"Cache-Control",
					"no-store",
				)
			}

			if request.Method == http.MethodOptions {
				if origin == "" {
					writeError(
						writer,
						http.StatusForbidden,
						"缺少 Origin",
					)

					return
				}

				writer.WriteHeader(
					http.StatusNoContent,
				)

				return
			}

			next.ServeHTTP(writer, request)
		},
	)
}

func writeSSE(
	writer io.Writer,
	eventName string,
	value any,
) error {
	data, err := json.Marshal(value)

	if err != nil {
		return err
	}

	_, err = fmt.Fprintf(
		writer,
		"event: %s\ndata: %s\n\n",
		eventName,
		data,
	)

	return err
}

func (a *app) publishMachine(machineID string) {
	machine, err := a.getMachine(machineID)

	if err == nil {
		a.broker.publish(event{
			Name: "machine",
			Data: machine,
		})
	}
}

func (a *app) handleHealth(
	writer http.ResponseWriter,
	request *http.Request,
) {
	if request.Method != http.MethodGet {
		writeError(
			writer,
			http.StatusMethodNotAllowed,
			"请求方法不支持",
		)
		return
	}

	writeJSON(
		writer,
		http.StatusOK,
		map[string]string{
			"status": "ok",
			"time":   nowString(),
		},
	)
}

func (a *app) handlePublicMachines(
	writer http.ResponseWriter,
	request *http.Request,
) {
	if request.Method != http.MethodGet {
		writeError(
			writer,
			http.StatusMethodNotAllowed,
			"请求方法不支持",
		)
		return
	}

	machines, err := a.listMachines()

	if err != nil {
		writeError(
			writer,
			http.StatusInternalServerError,
			"读取机器失败",
		)
		return
	}

	writeJSON(
		writer,
		http.StatusOK,
		map[string]any{
			"machines": machines,
		},
	)
}

func (a *app) handlePublicMachinePath(
	writer http.ResponseWriter,
	request *http.Request,
) {
	if request.Method != http.MethodGet {
		writeError(
			writer,
			http.StatusMethodNotAllowed,
			"请求方法不支持",
		)
		return
	}

	suffix := strings.Trim(
		strings.TrimPrefix(
			request.URL.Path,
			"/api/v1/public/machines/",
		),
		"/",
	)

	parts := strings.Split(suffix, "/")

	if len(parts) == 0 ||
		parts[0] == "" {
		writeError(
			writer,
			http.StatusNotFound,
			"机器不存在",
		)
		return
	}

	machineID := parts[0]

	if len(parts) == 1 {
		machine, err := a.getMachine(machineID)

		if errors.Is(err, sql.ErrNoRows) {
			writeError(
				writer,
				http.StatusNotFound,
				"机器不存在",
			)
			return
		}

		if err != nil {
			writeError(
				writer,
				http.StatusInternalServerError,
				"读取机器失败",
			)
			return
		}

		writeJSON(
			writer,
			http.StatusOK,
			map[string]any{
				"machine": machine,
			},
		)

		return
	}

	switch parts[1] {
	case "history":
		a.handleMachineHistory(
			writer,
			machineID,
		)

	case "sla":
		a.handleMachineSLA(
			writer,
			machineID,
		)

	default:
		writeError(
			writer,
			http.StatusNotFound,
			"接口不存在",
		)
	}
}

func (a *app) handleMachineHistory(
	writer http.ResponseWriter,
	machineID string,
) {
	rows, err := a.db.Query(`
		SELECT
			bucket_at,
			online,
			cpu_usage,
			memory_usage,
			disk_usage,
			network_download_bps,
			network_upload_bps
		FROM metrics_history
		WHERE
			machine_id = ?
			AND bucket_at >= ?
		ORDER BY bucket_at ASC
	`,
		machineID,
		time.Now().Add(
			-metricsRetention,
		).Unix(),
	)

	if err != nil {
		writeError(
			writer,
			http.StatusInternalServerError,
			"读取历史失败",
		)
		return
	}

	defer rows.Close()

	points := make([]historyPoint, 0)

	for rows.Next() {
		var point historyPoint
		var online int

		if err := rows.Scan(
			&point.Time,
			&online,
			&point.CPUUsage,
			&point.MemoryUsage,
			&point.DiskUsage,
			&point.NetworkDownloadBps,
			&point.NetworkUploadBps,
		); err != nil {
			writeError(
				writer,
				http.StatusInternalServerError,
				"读取历史失败",
			)
			return
		}

		point.Online = online == 1

		points = append(points, point)
	}

	writeJSON(
		writer,
		http.StatusOK,
		map[string]any{
			"rangeHours":     24,
			"intervalSeconds": 60,
			"points":          points,
		},
	)
}

func (a *app) handleMachineSLA(
	writer http.ResponseWriter,
	machineID string,
) {
	var firstSeen string

	err := a.db.QueryRow(`
		SELECT COALESCE(first_seen_at, '')
		FROM machines
		WHERE id = ?
	`, machineID).Scan(&firstSeen)

	if errors.Is(err, sql.ErrNoRows) {
		writeError(
			writer,
			http.StatusNotFound,
			"机器不存在",
		)
		return
	}

	if err != nil {
		writeError(
			writer,
			http.StatusInternalServerError,
			"读取 SLA 失败",
		)
		return
	}

	now := time.Now().UTC()
	start := now.Add(-slaRetention)

	if parsed, ok := parseTime(firstSeen);
		ok && parsed.After(start) {
		start = parsed
	}

	var observed int64
	var online int64

	err = a.db.QueryRow(`
		SELECT
			COUNT(*),
			COALESCE(SUM(online), 0)
		FROM availability_history
		WHERE
			machine_id = ?
			AND bucket_at >= ?
	`,
		machineID,
		start.Unix(),
	).Scan(
		&observed,
		&online,
	)

	if err != nil {
		writeError(
			writer,
			http.StatusInternalServerError,
			"读取 SLA 失败",
		)
		return
	}

	expected := int64(
		math.Ceil(
			now.Sub(start).Minutes(),
		),
	)

	if firstSeen == "" {
		expected = 0
	}

	unknown := expected - observed

	if unknown < 0 {
		unknown = 0
	}

	offline := observed - online
	sla := 0.0

	if observed > 0 {
		sla = float64(online) /
			float64(observed) *
			100
	}

	writeJSON(
		writer,
		http.StatusOK,
		slaResponse{
			Days:            30,
			OnlineMinutes:   online,
			OfflineMinutes:  offline,
			ObservedMinutes: observed,
			UnknownMinutes:  unknown,
			SLA: math.Round(
				sla*10000,
			) / 10000,
		},
	)
}

func (a *app) handlePublicEvents(
	writer http.ResponseWriter,
	request *http.Request,
) {
	flusher, ok := writer.(http.Flusher)

	if !ok {
		writeError(
			writer,
			http.StatusInternalServerError,
			"不支持实时推送",
		)
		return
	}

	writer.Header().Set(
		"Content-Type",
		"text/event-stream; charset=utf-8",
	)

	writer.Header().Set(
		"Cache-Control",
		"no-cache, no-store",
	)

	writer.Header().Set(
		"X-Accel-Buffering",
		"no",
	)

	channel := a.broker.subscribe()
	defer a.broker.unsubscribe(channel)

	machines, _ := a.listMachines()

	if err := writeSSE(
		writer,
		"snapshot",
		map[string]any{
			"machines": machines,
		},
	); err != nil {
		return
	}

	flusher.Flush()

	heartbeat := time.NewTicker(
		15 * time.Second,
	)

	defer heartbeat.Stop()

	for {
		select {
		case <-request.Context().Done():
			return

		case message := <-channel:
			if err := writeSSE(
				writer,
				message.Name,
				message.Data,
			); err != nil {
				return
			}

			flusher.Flush()

		case <-heartbeat.C:
			io.WriteString(
				writer,
				": heartbeat\n\n",
			)

			flusher.Flush()
		}
	}
}

func validateMachineInput(
	payload *machineInput,
) error {
	payload.Name = strings.TrimSpace(
		payload.Name,
	)

	payload.Provider = strings.TrimSpace(
		payload.Provider,
	)

	if payload.Name == "" {
		return errors.New("机器名称不能为空")
	}

	if len([]rune(payload.Name)) > 80 ||
		len([]rune(payload.Provider)) > 80 {
		return errors.New("字段长度不能超过 80")
	}

	return nil
}

func (a *app) handleAdminMachines(
	writer http.ResponseWriter,
	request *http.Request,
) {
	if !a.requireAdmin(writer, request) {
		return
	}

	switch request.Method {
	case http.MethodGet:
		machines, err := a.listMachines()

		if err != nil {
			writeError(
				writer,
				http.StatusInternalServerError,
				"读取机器失败",
			)
			return
		}

		writeJSON(
			writer,
			http.StatusOK,
			map[string]any{
				"machines": machines,
			},
		)

	case http.MethodPost:
		var payload machineInput

		if err := decodeJSON(
			writer,
			request,
			&payload,
		); err != nil {
			writeError(
				writer,
				http.StatusBadRequest,
				"JSON 不合法",
			)
			return
		}

		if err := validateMachineInput(
			&payload,
		); err != nil {
			writeError(
				writer,
				http.StatusUnprocessableEntity,
				err.Error(),
			)
			return
		}

		machineID, _ := randomHex(12)
		secret, _ := randomSecret(32)
		completeToken := machineID + "." + secret
		now := nowString()

		_, err := a.db.Exec(`
			INSERT INTO machines (
				id,
				name,
				provider,
				agent_token_hash,
				created_at,
				updated_at
			)
			VALUES (?, ?, ?, ?, ?, ?)
		`,
			machineID,
			payload.Name,
			payload.Provider,
			hashAgentSecret(secret),
			now,
			now,
		)

		if err != nil {
			writeError(
				writer,
				http.StatusInternalServerError,
				"创建机器失败",
			)
			return
		}

		machine, _ := a.getMachine(machineID)

		a.broker.publish(event{
			Name: "machine",
			Data: machine,
		})

		writeJSON(
			writer,
			http.StatusCreated,
			map[string]any{
				"machine":    machine,
				"agentToken": completeToken,
			},
		)

	default:
		writeError(
			writer,
			http.StatusMethodNotAllowed,
			"请求方法不支持",
		)
	}
}

func (a *app) handleAdminMachinePath(
	writer http.ResponseWriter,
	request *http.Request,
) {
	if !a.requireAdmin(writer, request) {
		return
	}

	suffix := strings.Trim(
		strings.TrimPrefix(
			request.URL.Path,
			"/api/v1/admin/machines/",
		),
		"/",
	)

	parts := strings.Split(suffix, "/")

	if len(parts) == 0 ||
		parts[0] == "" {
		writeError(
			writer,
			http.StatusNotFound,
			"机器不存在",
		)
		return
	}

	machineID := parts[0]

	if len(parts) == 1 {
		switch request.Method {
		case http.MethodPut:
			var payload machineInput

			if err := decodeJSON(
				writer,
				request,
				&payload,
			); err != nil {
				writeError(
					writer,
					http.StatusBadRequest,
					"JSON 不合法",
				)
				return
			}

			if err := validateMachineInput(
				&payload,
			); err != nil {
				writeError(
					writer,
					http.StatusUnprocessableEntity,
					err.Error(),
				)
				return
			}

			result, err := a.db.Exec(`
				UPDATE machines
				SET
					name = ?,
					provider = ?,
					updated_at = ?
				WHERE id = ?
			`,
				payload.Name,
				payload.Provider,
				nowString(),
				machineID,
			)

			if err != nil {
				writeError(
					writer,
					http.StatusInternalServerError,
					"更新失败",
				)
				return
			}

			affected, _ := result.RowsAffected()

			if affected == 0 {
				writeError(
					writer,
					http.StatusNotFound,
					"机器不存在",
				)
				return
			}

			machine, _ := a.getMachine(machineID)
			a.publishMachine(machineID)

			writeJSON(
				writer,
				http.StatusOK,
				map[string]any{
					"machine": machine,
				},
			)

		case http.MethodDelete:
			result, err := a.db.Exec(
				`DELETE FROM machines WHERE id = ?`,
				machineID,
			)

			if err != nil {
				writeError(
					writer,
					http.StatusInternalServerError,
					"删除失败",
				)
				return
			}

			affected, _ := result.RowsAffected()

			if affected == 0 {
				writeError(
					writer,
					http.StatusNotFound,
					"机器不存在",
				)
				return
			}

			a.broker.publish(event{
				Name: "deleted",
				Data: map[string]string{
					"id": machineID,
				},
			})

			writer.WriteHeader(
				http.StatusNoContent,
			)

		default:
			writeError(
				writer,
				http.StatusMethodNotAllowed,
				"请求方法不支持",
			)
		}

		return
	}

	if len(parts) == 2 &&
		parts[1] == "rotate-token" &&
		request.Method == http.MethodPost {
		secret, _ := randomSecret(32)

		result, err := a.db.Exec(`
			UPDATE machines
			SET
				agent_token_hash = ?,
				updated_at = ?
			WHERE id = ?
		`,
			hashAgentSecret(secret),
			nowString(),
			machineID,
		)

		if err != nil {
			writeError(
				writer,
				http.StatusInternalServerError,
				"Token 更新失败",
			)
			return
		}

		affected, _ := result.RowsAffected()

		if affected == 0 {
			writeError(
				writer,
				http.StatusNotFound,
				"机器不存在",
			)
			return
		}

		writeJSON(
			writer,
			http.StatusOK,
			map[string]string{
				"agentToken": machineID + "." + secret,
			},
		)

		return
	}

	if len(parts) == 3 &&
		parts[1] == "network" &&
		parts[2] == "refresh" &&
		request.Method == http.MethodPost {
		var ipHash sql.NullString

		err := a.db.QueryRow(`
			SELECT ip_hash
			FROM machines
			WHERE id = ?
		`, machineID).Scan(&ipHash)

		if err != nil {
			writeError(
				writer,
				http.StatusNotFound,
				"机器不存在",
			)
			return
		}

		transaction, _ := a.db.Begin()
		defer transaction.Rollback()

		if ipHash.Valid {
			transaction.Exec(
				`DELETE FROM network_cache WHERE ip_hash = ?`,
				ipHash.String,
			)
		}

		transaction.Exec(`
			UPDATE machines
			SET
				isp = NULL,
				organization = NULL,
				asn = NULL,
				as_name = NULL,
				network_type = NULL,
				city = NULL,
				region = NULL,
				country = NULL,
				latitude = NULL,
				longitude = NULL,
				risk_score = 0,
				network_checked_at = NULL,
				updated_at = ?
			WHERE id = ?
		`,
			nowString(),
			machineID,
		)

		transaction.Commit()
		a.publishMachine(machineID)

		writeJSON(
			writer,
			http.StatusOK,
			map[string]string{
				"message": "已清除网络缓存",
			},
		)

		return
	}

	writeError(
		writer,
		http.StatusNotFound,
		"接口不存在",
	)
}

var nonPublicPrefixes = []netip.Prefix{
	netip.MustParsePrefix("10.0.0.0/8"),
	netip.MustParsePrefix("100.64.0.0/10"),
	netip.MustParsePrefix("127.0.0.0/8"),
	netip.MustParsePrefix("169.254.0.0/16"),
	netip.MustParsePrefix("172.16.0.0/12"),
	netip.MustParsePrefix("192.168.0.0/16"),
	netip.MustParsePrefix("fc00::/7"),
	netip.MustParsePrefix("fe80::/10"),
	netip.MustParsePrefix("::1/128"),
}

func isPublicAddress(address netip.Addr) bool {
	address = address.Unmap()

	if !address.IsValid() ||
		!address.IsGlobalUnicast() {
		return false
	}

	for _, prefix := range nonPublicPrefixes {
		if prefix.Contains(address) {
			return false
		}
	}

	return true
}

func (a *app) sourceIP(
	request *http.Request,
) (string, bool) {
	host, _, err := net.SplitHostPort(
		request.RemoteAddr,
	)

	if err != nil {
		host = request.RemoteAddr
	}

	address, err := netip.ParseAddr(host)

	if err != nil {
		return "", false
	}

	address = address.Unmap()

	if address.IsLoopback() {
		if realIP := strings.TrimSpace(
			request.Header.Get("X-Real-IP"),
		); realIP != "" {
			if parsed, err :=
				netip.ParseAddr(realIP);
				err == nil {
				address = parsed.Unmap()
			}
		}
	}

	if !isPublicAddress(address) {
		return "", false
	}

	return address.String(), true
}

func (a *app) hashIP(ip string) string {
	mac := hmac.New(
		sha256.New,
		[]byte(a.config.IPHashKey),
	)

	mac.Write([]byte(ip))

	return hex.EncodeToString(mac.Sum(nil))
}

func (a *app) handleAgentReport(
	writer http.ResponseWriter,
	request *http.Request,
) {
	if request.Method != http.MethodPost {
		writeError(
			writer,
			http.StatusMethodNotAllowed,
			"请求方法不支持",
		)
		return
	}

	agent, err := a.authenticateAgent(request)

	if err != nil {
		writeError(
			writer,
			http.StatusUnauthorized,
			"Agent Token 无效",
		)
		return
	}

	var payload agentReport

	if err := decodeJSON(
		writer,
		request,
		&payload,
	); err != nil {
		writeError(
			writer,
			http.StatusBadRequest,
			"上报数据不合法",
		)
		return
	}

	if payload.CPUUsage < 0 ||
		payload.CPUUsage > 100 ||
		payload.CPUCores < 0 ||
		payload.MemoryTotalBytes < 0 ||
		payload.DiskTotalBytes < 0 ||
		payload.NetworkDownloadBps < 0 ||
		payload.NetworkUploadBps < 0 {
		writeError(
			writer,
			http.StatusUnprocessableEntity,
			"上报数值不合法",
		)
		return
	}

	memoryUsed := payload.MemoryUsedBytes

	if payload.MemoryTotalBytes > 0 &&
		memoryUsed > payload.MemoryTotalBytes {
		memoryUsed = payload.MemoryTotalBytes
	}

	diskUsed := payload.DiskUsedBytes

	if payload.DiskTotalBytes > 0 &&
		diskUsed > payload.DiskTotalBytes {
		diskUsed = payload.DiskTotalBytes
	}

	memoryUsage := 0.0

	if payload.MemoryTotalBytes > 0 {
		memoryUsage =
			float64(memoryUsed) /
				float64(payload.MemoryTotalBytes) *
				100
	}

	diskUsage := 0.0

	if payload.DiskTotalBytes > 0 {
		diskUsage =
			float64(diskUsed) /
				float64(payload.DiskTotalBytes) *
				100
	}

	sourceIP, hasSourceIP :=
		a.sourceIP(request)

	currentIPHash := agent.IPHash

	if hasSourceIP {
		currentIPHash = a.hashIP(sourceIP)
	}

	ipChanged :=
		currentIPHash != "" &&
			currentIPHash != agent.IPHash

	now := time.Now().UTC()
	nowText := now.Format(time.RFC3339Nano)

	onlineDelta := int64(0)

	if previous, ok := parseTime(
		agent.LastSeenAt,
	); ok {
		delta := now.Sub(previous)

		if delta > 0 &&
			delta <= a.config.OfflineAfter {
			onlineDelta = int64(
				delta.Seconds(),
			)
		}
	}

	transaction, err := a.db.Begin()

	if err != nil {
		writeError(
			writer,
			http.StatusInternalServerError,
			"数据库错误",
		)
		return
	}

	defer transaction.Rollback()

	if ipChanged {
		transaction.Exec(`
			UPDATE machines
			SET
				isp = NULL,
				organization = NULL,
				asn = NULL,
				as_name = NULL,
				network_type = NULL,
				city = NULL,
				region = NULL,
				country = NULL,
				latitude = NULL,
				longitude = NULL,
				risk_score = 0,
				hosting = NULL,
				proxy = NULL,
				vpn = NULL,
				tor = NULL,
				relay = NULL,
				network_checked_at = NULL
			WHERE id = ?
		`, agent.MachineID)
	}

	var storedIPHash any

	if currentIPHash != "" {
		storedIPHash = currentIPHash
	}

	_, err = transaction.Exec(`
		UPDATE machines
		SET
			os_id = ?,
			os_name = ?,
			os_version = ?,
			architecture = ?,

			cpu_cores = ?,
			cpu_usage = ?,

			memory_total_bytes = ?,
			memory_used_bytes = ?,
			memory_usage = ?,

			disk_total_bytes = ?,
			disk_used_bytes = ?,
			disk_usage = ?,

			network_download_bps = ?,
			network_upload_bps = ?,

			uptime_seconds = ?,
			total_online_seconds =
				total_online_seconds + ?,

			ip_hash = ?,

			first_seen_at =
				COALESCE(first_seen_at, ?),

			last_seen_at = ?,
			updated_at = ?
		WHERE id = ?
	`,
		trimLimit(payload.OSID, 50),
		trimLimit(payload.OSName, 100),
		trimLimit(payload.OSVersion, 100),
		trimLimit(payload.Architecture, 50),

		payload.CPUCores,
		clamp(payload.CPUUsage, 0, 100),

		payload.MemoryTotalBytes,
		memoryUsed,
		clamp(memoryUsage, 0, 100),

		payload.DiskTotalBytes,
		diskUsed,
		clamp(diskUsage, 0, 100),

		payload.NetworkDownloadBps,
		payload.NetworkUploadBps,

		payload.UptimeSeconds,
		onlineDelta,

		storedIPHash,

		nowText,
		nowText,
		nowText,
		agent.MachineID,
	)

	if err != nil {
		writeError(
			writer,
			http.StatusInternalServerError,
			"保存上报失败",
		)
		return
	}

	if err := transaction.Commit(); err != nil {
		writeError(
			writer,
			http.StatusInternalServerError,
			"保存上报失败",
		)
		return
	}

	networkFresh :=
		!ipChanged &&
			isFresh(
				agent.NetworkCheckedAt,
				a.config.NetworkTTL,
			)

	if hasSourceIP &&
		currentIPHash != "" &&
		!networkFresh {
		applied, err := a.applyNetworkCache(
			agent.MachineID,
			currentIPHash,
		)

		if err == nil && !applied {
			a.enqueueNetworkLookup(
				sourceIP,
				currentIPHash,
			)
		}
	}

	a.publishMachine(agent.MachineID)

	writer.WriteHeader(http.StatusNoContent)
}

func calculateRisk(privacy ipInfoPrivacy) int {
	score := 0

	if privacy.Hosting {
		score += 15
	}

	if privacy.Relay {
		score += 20
	}

	if privacy.Proxy {
		score += 30
	}

	if privacy.VPN {
		score += 35
	}

	if privacy.Tor {
		score += 60
	}

	return clampInt(score, 0, 100)
}

func firstNonEmpty(values ...string) string {
	for _, value := range values {
		value = strings.TrimSpace(value)

		if value != "" {
			return value
		}
	}

	return ""
}

func removeASNPrefix(value string) string {
	fields := strings.Fields(value)

	if len(fields) > 1 &&
		strings.HasPrefix(
			strings.ToUpper(fields[0]),
			"AS",
		) {
		return strings.Join(fields[1:], " ")
	}

	return strings.TrimSpace(value)
}

func parseCoordinates(
	value string,
) (*float64, *float64) {
	parts := strings.Split(value, ",")

	if len(parts) != 2 {
		return nil, nil
	}

	latitude, err1 := strconv.ParseFloat(
		strings.TrimSpace(parts[0]),
		64,
	)

	longitude, err2 := strconv.ParseFloat(
		strings.TrimSpace(parts[1]),
		64,
	)

	if err1 != nil ||
		err2 != nil ||
		latitude < -90 ||
		latitude > 90 ||
		longitude < -180 ||
		longitude > 180 {
		return nil, nil
	}

	return &latitude, &longitude
}

func classifyIPInfo(
	data ipInfoData,
) networkResult {
	asnType := strings.ToLower(
		strings.TrimSpace(data.ASN.Type),
	)

	companyType := strings.ToLower(
		strings.TrimSpace(data.Company.Type),
	)

	hosting :=
		data.Privacy.Hosting ||
			asnType == "hosting" ||
			companyType == "hosting"

	networkType := "UNKNOWN"

	switch {
	case hosting:
		networkType = "IDC"

	case asnType == "isp" ||
		companyType == "isp":
		networkType = "ISP"

	case asnType == "business" ||
		companyType == "business":
		networkType = "BUSINESS"

	case asnType == "education" ||
		companyType == "education":
		networkType = "EDUCATION"

	case asnType == "government" ||
		companyType == "government":
		networkType = "GOVERNMENT"
	}

	latitude, longitude :=
		parseCoordinates(data.Loc)

	return networkResult{
		ISP: firstNonEmpty(
			data.ASN.Name,
			data.Company.Name,
			removeASNPrefix(data.Org),
		),

		Organization: firstNonEmpty(
			data.Company.Name,
			data.ASN.Name,
		),

		ASN:         data.ASN.ASN,
		ASName:      data.ASN.Name,
		NetworkType: networkType,

		City:        data.City,
		Region:      data.Region,
		CountryCode: normalizeCountry(
			data.Country,
		),

		Latitude:  latitude,
		Longitude: longitude,

		RiskScore: calculateRisk(data.Privacy),

		Hosting: hosting,
		Proxy:   data.Privacy.Proxy,
		VPN:     data.Privacy.VPN,
		Tor:     data.Privacy.Tor,
		Relay:   data.Privacy.Relay,

		CheckedAt: nowString(),
	}
}

func (a *app) queryIPInfo(
	ip string,
) (networkResult, error) {
	endpoint :=
		a.config.IPInfoAPIBase +
			"/" +
			url.PathEscape(ip)

	request, err := http.NewRequest(
		http.MethodGet,
		endpoint,
		nil,
	)

	if err != nil {
		return networkResult{}, err
	}

	request.Header.Set(
		"Accept",
		"application/json",
	)

	request.Header.Set(
		"User-Agent",
		"VPS-Board/4.0",
	)

	response, err := a.httpClient.Do(request)

	if err != nil {
		return networkResult{}, err
	}

	defer response.Body.Close()

	if response.StatusCode < 200 ||
		response.StatusCode >= 300 {
		return networkResult{},
			fmt.Errorf(
				"IPinfo HTTP %d",
				response.StatusCode,
			)
	}

	body, err := io.ReadAll(
		io.LimitReader(
			response.Body,
			1024*1024,
		),
	)

	if err != nil {
		return networkResult{}, err
	}

	var decoded ipInfoWidgetResponse

	if err := json.Unmarshal(
		body,
		&decoded,
	); err != nil ||
		decoded.Data == nil {
		return networkResult{},
			errors.New("IPinfo JSON 无效")
	}

	requested, error1 :=
		netip.ParseAddr(ip)

	returned, error2 :=
		netip.ParseAddr(decoded.Data.IP)

	if error1 != nil ||
		error2 != nil ||
		requested.Unmap() != returned.Unmap() {
		return networkResult{},
			errors.New("IPinfo 返回地址不一致")
	}

	return classifyIPInfo(*decoded.Data), nil
}

func boolInt(value bool) int {
	if value {
		return 1
	}

	return 0
}

func (a *app) applyNetworkCache(
	machineID string,
	ipHash string,
) (bool, error) {
	var result networkResult
	var latitude sql.NullFloat64
	var longitude sql.NullFloat64
	var hosting, proxy, vpn, tor, relay int

	err := a.db.QueryRow(`
		SELECT
			isp,
			organization,
			asn,
			as_name,
			network_type,

			city,
			region,
			country,
			latitude,
			longitude,
			risk_score,

			hosting,
			proxy,
			vpn,
			tor,
			relay,

			checked_at
		FROM network_cache
		WHERE ip_hash = ?
	`, ipHash).Scan(
		&result.ISP,
		&result.Organization,
		&result.ASN,
		&result.ASName,
		&result.NetworkType,

		&result.City,
		&result.Region,
		&result.CountryCode,
		&latitude,
		&longitude,
		&result.RiskScore,

		&hosting,
		&proxy,
		&vpn,
		&tor,
		&relay,

		&result.CheckedAt,
	)

	if errors.Is(err, sql.ErrNoRows) {
		return false, nil
	}

	if err != nil ||
		!isFresh(
			result.CheckedAt,
			a.config.NetworkTTL,
		) {
		return false, err
	}

	var latitudeValue any
	var longitudeValue any

	if latitude.Valid {
		latitudeValue = latitude.Float64
	}

	if longitude.Valid {
		longitudeValue = longitude.Float64
	}

	_, err = a.db.Exec(`
		UPDATE machines
		SET
			isp = ?,
			organization = ?,
			asn = ?,
			as_name = ?,
			network_type = ?,

			city = ?,
			region = ?,
			country = ?,
			latitude = ?,
			longitude = ?,
			risk_score = ?,

			hosting = ?,
			proxy = ?,
			vpn = ?,
			tor = ?,
			relay = ?,

			network_checked_at = ?,
			updated_at = ?
		WHERE id = ?
	`,
		result.ISP,
		result.Organization,
		result.ASN,
		result.ASName,
		result.NetworkType,

		result.City,
		result.Region,
		result.CountryCode,
		latitudeValue,
		longitudeValue,
		result.RiskScore,

		hosting,
		proxy,
		vpn,
		tor,
		relay,

		result.CheckedAt,
		nowString(),
		machineID,
	)

	return err == nil, err
}

func (a *app) saveNetworkResult(
	ipHash string,
	result networkResult,
) error {
	transaction, err := a.db.Begin()

	if err != nil {
		return err
	}

	defer transaction.Rollback()

	_, err = transaction.Exec(`
		INSERT INTO network_cache (
			ip_hash,

			isp,
			organization,
			asn,
			as_name,
			network_type,

			city,
			region,
			country,
			latitude,
			longitude,
			risk_score,

			hosting,
			proxy,
			vpn,
			tor,
			relay,

			checked_at
		)
		VALUES (
			?, ?, ?, ?, ?, ?,
			?, ?, ?, ?, ?, ?,
			?, ?, ?, ?, ?,
			?
		)
		ON CONFLICT(ip_hash)
		DO UPDATE SET
			isp = excluded.isp,
			organization = excluded.organization,
			asn = excluded.asn,
			as_name = excluded.as_name,
			network_type = excluded.network_type,

			city = excluded.city,
			region = excluded.region,
			country = excluded.country,
			latitude = excluded.latitude,
			longitude = excluded.longitude,
			risk_score = excluded.risk_score,

			hosting = excluded.hosting,
			proxy = excluded.proxy,
			vpn = excluded.vpn,
			tor = excluded.tor,
			relay = excluded.relay,

			checked_at = excluded.checked_at
	`,
		ipHash,

		result.ISP,
		result.Organization,
		result.ASN,
		result.ASName,
		result.NetworkType,

		result.City,
		result.Region,
		result.CountryCode,
		nullableFloat(result.Latitude),
		nullableFloat(result.Longitude),
		result.RiskScore,

		boolInt(result.Hosting),
		boolInt(result.Proxy),
		boolInt(result.VPN),
		boolInt(result.Tor),
		boolInt(result.Relay),

		result.CheckedAt,
	)

	if err != nil {
		return err
	}

	_, err = transaction.Exec(`
		UPDATE machines
		SET
			isp = ?,
			organization = ?,
			asn = ?,
			as_name = ?,
			network_type = ?,

			city = ?,
			region = ?,
			country = ?,
			latitude = ?,
			longitude = ?,
			risk_score = ?,

			hosting = ?,
			proxy = ?,
			vpn = ?,
			tor = ?,
			relay = ?,

			network_checked_at = ?,
			updated_at = ?
		WHERE ip_hash = ?
	`,
		result.ISP,
		result.Organization,
		result.ASN,
		result.ASName,
		result.NetworkType,

		result.City,
		result.Region,
		result.CountryCode,
		nullableFloat(result.Latitude),
		nullableFloat(result.Longitude),
		result.RiskScore,

		boolInt(result.Hosting),
		boolInt(result.Proxy),
		boolInt(result.VPN),
		boolInt(result.Tor),
		boolInt(result.Relay),

		result.CheckedAt,
		nowString(),
		ipHash,
	)

	if err != nil {
		return err
	}

	rows, err := transaction.Query(`
		SELECT id
		FROM machines
		WHERE ip_hash = ?
	`, ipHash)

	if err != nil {
		return err
	}

	var machineIDs []string

	for rows.Next() {
		var machineID string

		if err := rows.Scan(&machineID); err != nil {
			rows.Close()
			return err
		}

		machineIDs = append(
			machineIDs,
			machineID,
		)
	}

	rows.Close()

	if err := transaction.Commit(); err != nil {
		return err
	}

	for _, machineID := range machineIDs {
		a.publishMachine(machineID)
	}

	return nil
}

func (a *app) enqueueNetworkLookup(
	ip string,
	ipHash string,
) {
	a.networkMutex.Lock()

	if _, exists :=
		a.pendingNetworks[ipHash];
		exists {
		a.networkMutex.Unlock()
		return
	}

	if until, exists :=
		a.networkCooldowns[ipHash];
		exists &&
			time.Now().Before(until) {
		a.networkMutex.Unlock()
		return
	}

	a.pendingNetworks[ipHash] = struct{}{}
	a.networkMutex.Unlock()

	select {
	case a.networkQueue <- networkJob{
		IP:     ip,
		IPHash: ipHash,
	}:

	default:
		a.networkMutex.Lock()
		delete(a.pendingNetworks, ipHash)
		a.networkMutex.Unlock()
	}
}

func (a *app) networkWorker(
	ctx context.Context,
) {
	for {
		select {
		case <-ctx.Done():
			return

		case job := <-a.networkQueue:
			result, err := a.queryIPInfo(job.IP)

			a.networkMutex.Lock()
			delete(a.pendingNetworks, job.IPHash)

			if err != nil {
				a.networkCooldowns[job.IPHash] =
					time.Now().Add(
						a.config.NetworkFailureCooldown,
					)
			} else {
				delete(
					a.networkCooldowns,
					job.IPHash,
				)
			}

			a.networkMutex.Unlock()

			if err != nil {
				log.Printf(
					"IPinfo 查询失败，哈希=%s",
					job.IPHash[:10],
				)
			} else if err := a.saveNetworkResult(
				job.IPHash,
				result,
			); err != nil {
				log.Printf(
					"保存 IPinfo 结果失败",
				)
			}

			select {
			case <-ctx.Done():
				return

			case <-time.After(
				a.config.IPInfoRequestInterval,
			):
			}
		}
	}
}

type historySnapshot struct {
	ID string

	FirstSeenAt string
	LastSeenAt  string

	CPUUsage    float64
	MemoryUsage float64
	DiskUsage   float64

	Download float64
	Upload   float64
}

func (a *app) sampleHistory() error {
	rows, err := a.db.Query(`
		SELECT
			id,
			COALESCE(first_seen_at, ''),
			COALESCE(last_seen_at, ''),
			COALESCE(cpu_usage, 0),
			COALESCE(memory_usage, 0),
			COALESCE(disk_usage, 0),
			COALESCE(network_download_bps, 0),
			COALESCE(network_upload_bps, 0)
		FROM machines
	`)

	if err != nil {
		return err
	}

	var snapshots []historySnapshot

	for rows.Next() {
		var snapshot historySnapshot

		if err := rows.Scan(
			&snapshot.ID,
			&snapshot.FirstSeenAt,
			&snapshot.LastSeenAt,
			&snapshot.CPUUsage,
			&snapshot.MemoryUsage,
			&snapshot.DiskUsage,
			&snapshot.Download,
			&snapshot.Upload,
		); err != nil {
			rows.Close()
			return err
		}

		snapshots = append(
			snapshots,
			snapshot,
		)
	}

	rows.Close()

	bucket := time.Now().
		UTC().
		Truncate(time.Minute).
		Unix()

	transaction, err := a.db.Begin()

	if err != nil {
		return err
	}

	defer transaction.Rollback()

	for _, snapshot := range snapshots {
		if snapshot.FirstSeenAt == "" {
			continue
		}

		online := 0

		if isFresh(
			snapshot.LastSeenAt,
			a.config.OfflineAfter,
		) {
			online = 1
		}

		transaction.Exec(`
			INSERT INTO availability_history (
				machine_id,
				bucket_at,
				online
			)
			VALUES (?, ?, ?)
			ON CONFLICT(machine_id, bucket_at)
			DO UPDATE SET
				online = excluded.online
		`,
			snapshot.ID,
			bucket,
			online,
		)

		transaction.Exec(`
			INSERT INTO metrics_history (
				machine_id,
				bucket_at,
				online,

				cpu_usage,
				memory_usage,
				disk_usage,

				network_download_bps,
				network_upload_bps
			)
			VALUES (?, ?, ?, ?, ?, ?, ?, ?)
			ON CONFLICT(machine_id, bucket_at)
			DO UPDATE SET
				online =
					excluded.online,

				cpu_usage =
					excluded.cpu_usage,

				memory_usage =
					excluded.memory_usage,

				disk_usage =
					excluded.disk_usage,

				network_download_bps =
					excluded.network_download_bps,

				network_upload_bps =
					excluded.network_upload_bps
		`,
			snapshot.ID,
			bucket,
			online,

			snapshot.CPUUsage,
			snapshot.MemoryUsage,
			snapshot.DiskUsage,

			snapshot.Download,
			snapshot.Upload,
		)
	}

	return transaction.Commit()
}

func (a *app) cleanupHistory() {
	a.db.Exec(`
		DELETE FROM availability_history
		WHERE bucket_at < ?
	`,
		time.Now().Add(
			-slaRetention,
		).Unix(),
	)

	a.db.Exec(`
		DELETE FROM metrics_history
		WHERE bucket_at < ?
	`,
		time.Now().Add(
			-metricsRetention,
		).Unix(),
	)
}

func (a *app) historyWorker(
	ctx context.Context,
) {
	a.sampleHistory()
	a.cleanupHistory()

	ticker := time.NewTicker(time.Minute)
	defer ticker.Stop()

	counter := 0

	for {
		select {
		case <-ctx.Done():
			return

		case <-ticker.C:
			if err := a.sampleHistory(); err != nil {
				log.Printf("历史采样失败")
			}

			counter++

			if counter%10 == 0 {
				a.cleanupHistory()
			}
		}
	}
}

func (a *app) routes() http.Handler {
	mux := http.NewServeMux()

	mux.HandleFunc(
		"/api/v1/health",
		a.handleHealth,
	)

	mux.HandleFunc(
		"/api/v1/public/machines",
		a.handlePublicMachines,
	)

	mux.HandleFunc(
		"/api/v1/public/machines/",
		a.handlePublicMachinePath,
	)

	mux.HandleFunc(
		"/api/v1/public/events",
		a.handlePublicEvents,
	)

	mux.HandleFunc(
		"/api/v1/admin/machines",
		a.handleAdminMachines,
	)

	mux.HandleFunc(
		"/api/v1/admin/machines/",
		a.handleAdminMachinePath,
	)

	mux.HandleFunc(
		"/api/v1/agent/report",
		a.handleAgentReport,
	)

	return a.middleware(mux)
}

func main() {
	configuration := loadConfig()

	instance, err := newApp(configuration)

	if err != nil {
		log.Fatal(err)
	}

	defer instance.db.Close()

	ctx, cancel := context.WithCancel(
		context.Background(),
	)

	defer cancel()

	go instance.networkWorker(ctx)
	go instance.historyWorker(ctx)

	server := &http.Server{
		Addr:    configuration.ListenAddress,
		Handler: instance.routes(),

		ReadHeaderTimeout: 10 * time.Second,
		ReadTimeout:       20 * time.Second,
		WriteTimeout:      0,
		IdleTimeout:       90 * time.Second,

		ErrorLog: log.New(
			io.Discard,
			"",
			0,
		),
	}

	signals := make(chan os.Signal, 1)

	signal.Notify(
		signals,
		syscall.SIGINT,
		syscall.SIGTERM,
	)

	go func() {
		<-signals
		cancel()

		shutdownContext, shutdownCancel :=
			context.WithTimeout(
				context.Background(),
				10*time.Second,
			)

		defer shutdownCancel()

		server.Shutdown(shutdownContext)
	}()

	log.Printf(
		"VPS Board API 正在监听 %s",
		configuration.ListenAddress,
	)

	err = server.ListenAndServe()

	if err != nil &&
		!errors.Is(
			err,
			http.ErrServerClosed,
		) {
		log.Fatal(err)
	}
}